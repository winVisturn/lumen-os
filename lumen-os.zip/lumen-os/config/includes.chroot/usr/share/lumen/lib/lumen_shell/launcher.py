"""Full-screen app launcher with search (Super+Space, or the grid button in the dock)."""
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GdkX11", "3.0")
from gi.repository import Gdk, GdkX11, GLib, Gtk, Pango  # noqa: E402

from lumen import apps, ui  # noqa: E402

ICON = 56


class Launcher(Gtk.Window):
    def __init__(self, shell):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.shell = shell
        self._anim = None
        self._hiding = False
        self._menu_open = False
        self._last_hide = 0
        self.set_title("lumen-launcher")
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_type_hint(Gdk.WindowTypeHint.NORMAL)

        self.root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        ui.css_class(self.root, "lumen-launcher")
        self.add(self.root)
        ui.setup_transparency(self, self.root)

        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=26)
        self.content.set_margin_top(80)
        self.content.set_margin_bottom(110)
        self.root.pack_start(self.content, True, True, 0)

        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text("Search apps")
        self.search.set_halign(Gtk.Align.CENTER)
        self.search.set_size_request(440, -1)
        ui.css_class(self.search, "launcher-search")
        self.search.connect("search-changed", self.on_search)
        self.search.connect("activate", self.on_activate_first)
        self.content.pack_start(self.search, False, False, 0)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_propagate_natural_height(False)
        self.grid = Gtk.FlowBox()
        ui.css_class(self.grid, "launcher-grid")
        self.grid.set_valign(Gtk.Align.START)
        self.grid.set_halign(Gtk.Align.CENTER)
        self.grid.set_max_children_per_line(7)
        self.grid.set_min_children_per_line(3)
        self.grid.set_column_spacing(18)
        self.grid.set_row_spacing(14)
        self.grid.set_homogeneous(True)
        self.grid.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.grid.set_activate_on_single_click(True)
        self.grid.set_filter_func(self._filter)
        self.grid.connect("child-activated", self.on_child_activated)
        scroller.add(self.grid)
        self.content.pack_start(scroller, True, True, 0)

        self.empty = ui.label("No apps found", "launcher-empty", xalign=0.5)
        self.empty.set_no_show_all(True)
        self.content.pack_start(self.empty, False, False, 0)

        self.connect("key-press-event", self.on_key)
        self.connect("focus-out-event", self.on_focus_out)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("button-press-event", self.on_background_click)
        self.connect("delete-event", lambda *_a: self.hide_launcher() or True)

        shell.index.connect_changed(self.populate)
        self.populate()

    # ------------------------------------------------------------ contents
    def populate(self):
        for child in self.grid.get_children():
            self.grid.remove(child)
        for app in self.shell.index.visible():
            self.grid.add(self._make_child(app))
        self.grid.show_all()

    def _make_child(self, app):
        child = Gtk.FlowBoxChild()
        child.app = app
        name = apps.display_name(app)
        keywords = [name, app.get_name() or "", app.get_generic_name() or "", app.get_id(),
                    app.get_description() or "", " ".join(app.get_keywords() or [])]
        child.search_text = " ".join(keywords).lower()
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        tile = apps.make_tile(app, ICON)
        tile.set_halign(Gtk.Align.CENTER)
        box.pack_start(tile, False, False, 0)
        lbl = Gtk.Label(label=name)
        lbl.set_justify(Gtk.Justification.CENTER)
        lbl.set_ellipsize(Pango.EllipsizeMode.END)
        lbl.set_max_width_chars(14)
        lbl.set_width_chars(12)
        box.pack_start(lbl, False, False, 0)
        ev = Gtk.EventBox()
        ev.set_visible_window(False)
        ev.add(box)
        ev.connect("button-press-event", lambda _w, e: self._child_menu(child, e))
        child.add(ev)
        child.set_tooltip_text(app.get_description() or name)
        return child

    def _filter(self, child):
        q = self.search.get_text().strip().lower()
        if not q:
            return True
        return all(word in child.search_text for word in q.split())

    def on_search(self, _e):
        self.grid.invalidate_filter()
        first = self._first_visible()
        if first is not None:
            self.grid.select_child(first)
        self.empty.set_visible(first is None)

    def _first_visible(self):
        for c in self.grid.get_children():
            if c.get_child_visible() and self._filter(c):
                return c
        return None

    def on_activate_first(self, _e):
        sel = self.grid.get_selected_children()
        child = sel[0] if sel else self._first_visible()
        if child is not None:
            self.on_child_activated(self.grid, child)

    def on_child_activated(self, _grid, child):
        app = child.app
        self.hide_launcher()
        GLib.timeout_add(60, lambda: (self._launch(app), False)[1])

    def _launch(self, app):
        if apps.launch(app):
            item = self.shell.dock.items.get(app.get_id())
            if item is not None and not item.windows:
                item.bounce()

    def _child_menu(self, child, event):
        if event.type != Gdk.EventType.BUTTON_PRESS or event.button != 3:
            return False
        app = child.app
        menu = Gtk.Menu()
        pinned = app.get_id() in self.shell.dock.pinned()
        mi = Gtk.MenuItem(label="Remove from dock" if pinned else "Add to dock")
        mi.connect("activate", lambda *_a: self.shell.dock.set_pinned(app.get_id(), not pinned))
        menu.append(mi)
        menu.show_all()
        menu.attach_to_widget(child, None)
        self._menu_open = True

        def closed(*_a):
            self._menu_open = False
            self._present()
        menu.connect("deactivate", closed)
        menu.popup_at_pointer(event)
        return True

    # ------------------------------------------------------------ show / hide
    def on_focus_out(self, *_a):
        # A right-click menu takes focus for a moment: don't close for that.
        if self.get_visible() and not self._menu_open:
            self.hide_launcher()
        return False

    def toggle(self):
        if self.get_visible() and not self._hiding:
            self.hide_launcher()
        elif GLib.get_monotonic_time() - self._last_hide < 350000:
            # It just closed because the click that toggles it took its focus.
            return
        else:
            self.show_launcher()

    def show_launcher(self):
        if self._anim:
            self._anim.cancel()
        self._hiding = False
        g = ui.primary_geometry()
        self.move(g.x, g.y)
        self.set_default_size(g.width, g.height)
        self.resize(g.width, g.height)
        self.search.set_text("")
        self.grid.unselect_all()
        self.empty.hide()
        animated = self.shell.settings.get("animations", "full") != "off"
        self.set_opacity(0.0 if animated else 1.0)
        self.show_all()
        self.empty.set_visible(False)
        self._present()
        self.search.grab_focus()

        def step(t):
            self.set_opacity(t)
            self.content.set_margin_top(int(80 + 18 * (1 - t)))
        self._anim = ui.Anim(self, 180, step, enabled=animated)

    def _present(self):
        win = self.get_window()
        ts = Gtk.get_current_event_time()
        if not ts and isinstance(win, GdkX11.X11Window):
            ts = GdkX11.x11_get_server_time(win)
        self.present_with_time(ts)
        if win is not None:
            win.focus(ts)

    def hide_launcher(self):
        if not self.get_visible() or self._hiding:
            return
        self._hiding = True
        self._last_hide = GLib.get_monotonic_time()
        if self._anim:
            self._anim.cancel()
        animated = self.shell.settings.get("animations", "full") != "off"

        def done():
            self.hide()
            self._hiding = False
            self.set_opacity(1.0)
        self._anim = ui.Anim(self, 120, lambda t: self.set_opacity(1 - t), done, enabled=animated)

    def on_key(self, _w, event):
        key = event.keyval
        if key == Gdk.KEY_Escape:
            if self.search.get_text():
                self.search.set_text("")
            else:
                self.hide_launcher()
            return True
        if key in (Gdk.KEY_Down, Gdk.KEY_Up, Gdk.KEY_Left, Gdk.KEY_Right) and self.search.has_focus():
            first = self.grid.get_selected_children() or [self._first_visible()]
            if first and first[0] is not None:
                first[0].grab_focus()
            return key in (Gdk.KEY_Down, Gdk.KEY_Up)
        if not self.search.has_focus() and event.string and event.string.isprintable() and len(event.string) == 1:
            self.search.grab_focus_without_selecting()
            return self.search.event(event)
        return False

    def on_background_click(self, _w, event):
        # Clicking on empty space (not an app) closes the launcher.
        widget = Gtk.get_event_widget(event)
        while widget is not None:
            if isinstance(widget, (Gtk.FlowBoxChild, Gtk.Entry)):
                return False
            widget = widget.get_parent()
        self.hide_launcher()
        return False
