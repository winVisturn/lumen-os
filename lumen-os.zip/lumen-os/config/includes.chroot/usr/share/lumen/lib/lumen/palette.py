"""Colour palettes for the three Lumen modes.

Light    - the default, soft blue-grey light theme.
Soft dim - mid-tone backgrounds with dark text (easy on the eyes, not dark).
Dusk     - a blue-grey dark theme with deliberately low contrast: no pure
           white text anywhere.
"""
from .config import ACCENTS

MODE_COLOURS = {
    "light": dict(
        dark=False,
        bg="#F3F5F7", bg_alt="#E9EDF1", surface="#FFFFFF", surface_alt="#F7F9FA",
        border="#D6DDE3", fg="#1F2A33", fg_dim="#5B6873", hover="#E1E7EC",
        bar=(232, 236, 240, 0.86), dock=(226, 231, 236, 0.74), launcher=(236, 240, 243, 0.82),
        titlebar="#EEF1F4", titlebar_inactive="#F3F5F7",
        button_dot="#C9D1D8", button_dot_hover="#9EAAB4", close="#D9645A",
        terminal_bg="#EEF1F4", terminal_fg="#26323B",
    ),
    "softdim": dict(
        dark=False,
        bg="#CCD4DB", bg_alt="#C2CAD2", surface="#D8DEE4", surface_alt="#D1D8DE",
        border="#AEB9C3", fg="#1B252D", fg_dim="#44515C", hover="#BAC4CD",
        bar=(190, 200, 209, 0.88), dock=(184, 195, 205, 0.80), launcher=(196, 205, 213, 0.86),
        titlebar="#C6CED6", titlebar_inactive="#CCD4DB",
        button_dot="#A4B0BB", button_dot_hover="#7D8B97", close="#B9564D",
        terminal_bg="#D1D8DE", terminal_fg="#1B252D",
    ),
    "dusk": dict(
        dark=True,
        bg="#3A4551", bg_alt="#343E49", surface="#424E5B", surface_alt="#3E4955",
        border="#505D6A", fg="#C7D0D9", fg_dim="#97A3AF", hover="#4A5764",
        bar=(52, 62, 73, 0.88), dock=(48, 58, 68, 0.80), launcher=(44, 53, 62, 0.86),
        titlebar="#36414C", titlebar_inactive="#3A4551",
        button_dot="#5A6774", button_dot_hover="#7B8996", close="#C0675E",
        terminal_bg="#323C47", terminal_fg="#C2CCD5",
    ),
}

# Fixed colours for the dock / launcher app tiles (from the Lumen mockup).
TILE_COLOURS = {
    "files": "#8AAFC0",
    "browser": "#5C6E9E",
    "terminal": "#3A4048",
    "music": "#C46F49",
    "editor": "#5E8A55",
    "settings": "#8E99A8",
    "images": "#9C7AA8",
    "install": "#2E6E7E",
    "archive": "#A88B5E",
    "utility": None,      # uses the surface colour
}


def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_to_hex(rgb):
    return "#%02X%02X%02X" % tuple(max(0, min(255, round(c))) for c in rgb)


def mix(a, b, t):
    """Mix colour a towards b by t (0..1)."""
    ra, rb = hex_to_rgb(a), hex_to_rgb(b)
    return rgb_to_hex(tuple(x + (y - x) * t for x, y in zip(ra, rb)))


def rgba(colour, alpha):
    if isinstance(colour, tuple):
        r, g, b = colour[:3]
    else:
        r, g, b = hex_to_rgb(colour)
    return "rgba(%d,%d,%d,%.2f)" % (r, g, b, alpha)


def rgba_tuple(t):
    return "rgba(%d,%d,%d,%.2f)" % t


def build(mode, accent):
    """Return a flat dict of every colour the theme engine needs."""
    p = dict(MODE_COLOURS.get(mode, MODE_COLOURS["light"]))
    base_accent = ACCENTS.get(accent, ACCENTS["teal"])[1]
    if p["dark"]:
        # Lighter accent with dark text on it: no bright white text in Dusk.
        p["accent"] = mix(base_accent, "#FFFFFF", 0.28)
        p["accent_fg"] = "#1C252E"
    else:
        p["accent"] = base_accent
        p["accent_fg"] = "#F4F6F8"
    p["accent_soft"] = rgba(p["accent"], 0.16 if not p["dark"] else 0.24)
    p["accent_softer"] = rgba(p["accent"], 0.09 if not p["dark"] else 0.14)
    p["selection_text"] = p["fg"]
    p["shadow"] = "rgba(20,28,36,0.16)" if not p["dark"] else "rgba(0,0,0,0.30)"
    p["mode"] = mode
    p["accent_name"] = accent
    return p
