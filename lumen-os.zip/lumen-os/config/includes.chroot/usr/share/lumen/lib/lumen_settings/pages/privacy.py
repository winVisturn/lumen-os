"""Privacy: recent files, thumbnails, and an honest statement about data."""
import os
import shutil

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk  # noqa: E402

from lumen import config, ui  # noqa: E402
from ..widgets import Page, button, confirm, switch  # noqa: E402


class PrivacyPage(Page):
    title = "Privacy"

    def __init__(self, app):
        super().__init__(app)
        s = config.load()
        self.section("History")
        hist = self.card()
        hist.row("Remember recently used files", "Apps can show files you opened recently.",
                 switch(s["remember_recent"], self.on_recent))
        hist.row("Clear recent files", "Removes the list of recently opened files.",
                 button("Clear", self.clear_recent))
        hist.row("Clear picture previews", "Deletes saved thumbnails. They're made again when needed.",
                 button("Clear", self.clear_thumbnails))

        self.section("Your data")
        info = self.card()
        info.row("Lumen OS doesn't collect anything",
                 "There's no tracking, no usage statistics and no account. "
                 "Only the apps you choose (like the web browser) connect to the internet.")
        info.row("Location", "Lumen doesn't use your location.")

    def on_recent(self, value):
        config.update(remember_recent=value)
        ui.run_async(["lumen-theme", "apply"])
        if not value:
            self._remove(os.path.expanduser("~/.local/share/recently-used.xbel"))

    def clear_recent(self):
        if confirm(self.window, "Clear recent files?", "Apps will no longer list the files you opened recently.",
                   "Clear"):
            self._remove(os.path.expanduser("~/.local/share/recently-used.xbel"))

    def clear_thumbnails(self):
        shutil.rmtree(os.path.expanduser("~/.cache/thumbnails"), ignore_errors=True)
        ui.run_async(["notify-send", "-i", "edit-clear", "Picture previews cleared"])

    def _remove(self, path):
        try:
            os.remove(path)
        except OSError:
            pass
        ui.run_async(["notify-send", "-i", "edit-clear", "Recent files cleared"])
