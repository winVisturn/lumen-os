"""Finding, naming, drawing and launching apps (shared by shell and Settings)."""
import os
import subprocess

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk  # noqa: E402


class Known:
    def __init__(self, tile, glyph, name):
        self.tile, self.glyph, self.name = tile, glyph, name


# Keywords found in a .desktop id -> how Lumen draws and names that app.
KNOWN = [
    (("lumen-settings",), Known("settings", "emblem-system-symbolic", "Settings")),
    (("lumen-install", "install-debian", "calamares"), Known("install", "system-software-install-symbolic", "Install Lumen OS")),
    (("thunar", "nautilus", "pcmanfm", "nemo"), Known("files", "folder-symbolic", "Files")),
    (("firefox", "chromium", "browser"), Known("browser", "web-browser-symbolic", None)),
    (("terminal", "xterm"), Known("terminal", "utilities-terminal-symbolic", "Terminal")),
    (("parole", "audacious", "rhythmbox", "lollypop"), Known("music", "audio-x-generic-symbolic", "Media Player")),
    (("mousepad", "gedit", "text-editor", "featherpad"), Known("editor", "document-edit-symbolic", "Text Editor")),
    (("ristretto", "eog", "viewnior", "shotwell"), Known("images", "image-x-generic-symbolic", "Images")),
    (("xarchiver", "file-roller", "engrampa"), Known("archive", "package-x-generic-symbolic", "Archives")),
]


def known_for(app_id):
    if not app_id:
        return None
    low = app_id.lower()
    if "settings" in low and "lumen" not in low:
        return None        # e.g. xfce4-terminal-settings: draw it plainly
    for keys, k in KNOWN:
        if any(key in low for key in keys):
            return k
    return None


def display_name(app):
    k = known_for(app.get_id())
    if k and k.name:
        return k.name
    return app.get_display_name() or app.get_name() or app.get_id()


def _has_icon(name):
    try:
        return Gtk.IconTheme.get_default().has_icon(name)
    except Exception:
        return False


def make_tile(app, size, pixbuf=None, glyph=None, tile=None):
    """A rounded coloured square with a white glyph (Lumen style), or the
    app's own icon if Lumen doesn't know the app."""
    box = Gtk.Box()
    box.set_size_request(size, size)
    ctx = box.get_style_context()
    ctx.add_class("dock-tile")
    k = known_for(app.get_id()) if app is not None else None
    if glyph is None and k is not None and _has_icon(k.glyph):
        glyph, tile = k.glyph, k.tile
    if glyph:
        ctx.add_class("tile-" + (tile or "utility"))
        img = Gtk.Image.new_from_icon_name(glyph, Gtk.IconSize.DIALOG)
        img.set_pixel_size(max(16, int(size * 0.5)))
    else:
        ctx.add_class("tile-plain")
        if pixbuf is not None:
            pb = pixbuf.scale_simple(size, size, GdkPixbuf.InterpType.BILINEAR)
            img = Gtk.Image.new_from_pixbuf(pb)
        else:
            icon = app.get_icon() if app is not None else None
            if icon is None:
                icon = Gio.ThemedIcon.new("application-x-executable")
            img = Gtk.Image.new_from_gicon(icon, Gtk.IconSize.DIALOG)
            img.set_pixel_size(size)
    img.set_halign(Gtk.Align.CENTER)
    img.set_valign(Gtk.Align.CENTER)
    box.pack_start(img, True, True, 0)
    return box


class AppIndex:
    """All installed apps, plus a way to tell which app a window belongs to."""

    def __init__(self):
        self.apps = {}
        self.by_key = {}
        self._listeners = []
        self.refresh()
        self._monitor = Gio.AppInfoMonitor.get()
        self._monitor.connect("changed", self._changed)

    def connect_changed(self, fn):
        self._listeners.append(fn)

    def _changed(self, *_a):
        self.refresh()
        for fn in self._listeners:
            fn()

    def refresh(self):
        apps = [a for a in Gio.AppInfo.get_all() if isinstance(a, Gio.DesktopAppInfo)]
        apps.sort(key=lambda a: (not a.should_show(), a.get_id()))
        self.apps = {a.get_id(): a for a in apps}
        by_key = {}
        for a in apps:
            app_id = a.get_id()
            base = app_id[:-8] if app_id.endswith(".desktop") else app_id
            keys = {base.lower(), base.split(".")[-1].lower()}
            wm = a.get_startup_wm_class()
            if wm:
                keys.add(wm.lower())
            exe = a.get_executable()
            if exe:
                keys.add(os.path.basename(exe).lower())
            for k in keys:
                by_key.setdefault(k, app_id)
        self.by_key = by_key

    def visible(self):
        return sorted((a for a in self.apps.values() if a.should_show()),
                      key=lambda a: display_name(a).lower())

    def get(self, app_id):
        if app_id in self.apps:
            return self.apps[app_id]
        low = app_id.lower()
        for k, a in self.apps.items():
            if k.lower() == low:
                return a
        base = low[:-8] if low.endswith(".desktop") else low
        other = self.by_key.get(base) or self.by_key.get(base.split(".")[-1])
        return self.apps.get(other) if other else None

    def id_for_window(self, w):
        for name in (w.get_class_group_name(), w.get_class_instance_name()):
            if name:
                app_id = self.by_key.get(name.lower())
                if app_id:
                    return app_id
        return None


def launch_context():
    display = Gdk.Display.get_default()
    ctx = display.get_app_launch_context()
    ctx.set_timestamp(Gtk.get_current_event_time())
    return ctx


def notify(summary, body="", icon="lumen-logo"):
    try:
        subprocess.Popen(["notify-send", "-i", icon, summary, body],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        pass


def launch(app, uris=None):
    try:
        app.launch_uris(uris or [], launch_context())
        return True
    except GLib.Error as e:
        notify("Couldn't open %s" % display_name(app), e.message)
        return False


def open_uri(uri):
    try:
        Gio.AppInfo.launch_default_for_uri(uri, launch_context())
        return True
    except GLib.Error as e:
        notify("Couldn't open that", e.message)
        return False


def spawn(argv):
    """Start a program and forget about it."""
    try:
        subprocess.Popen(argv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
        return True
    except OSError as e:
        notify("Couldn't run %s" % argv[0], str(e))
        return False
