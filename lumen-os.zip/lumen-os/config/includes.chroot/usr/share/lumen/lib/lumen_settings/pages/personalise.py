"""Personalise: mode, accent colour, wallpaper, animations, dock and top bar."""
import os
import shutil

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GdkPixbuf, GLib, Gtk  # noqa: E402

from lumen import config, ui  # noqa: E402
from ..widgets import Page, Segmented, button, switch  # noqa: E402

THUMB_W, THUMB_H = 176, 110


def thumbnail(path):
    try:
        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, -1, THUMB_H, True)
    except GLib.Error:
        return None
    if pb.get_width() < THUMB_W:
        pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, THUMB_W, -1, True)
    x = max(0, (pb.get_width() - THUMB_W) // 2)
    y = max(0, (pb.get_height() - THUMB_H) // 2)
    return pb.new_subpixbuf(x, y, min(THUMB_W, pb.get_width()), min(THUMB_H, pb.get_height()))


class PersonalisePage(Page):
    title = "Personalise"

    def __init__(self, app):
        super().__init__(app)
        s = config.load()

        self.section("Appearance")
        look = self.card()
        look.row("Mode", "Soft dim and Dusk are gentler on the eyes in the evening.",
                 Segmented(list(config.MODES.items()), s["mode"], self.on_mode))
        swatches = Gtk.Box(spacing=8)
        self.swatch_buttons = {}
        for key, (label, _colour) in config.ACCENTS.items():
            b = Gtk.Button()
            b.set_tooltip_text(label)
            ui.css_class(b, "swatch", "swatch-" + key)
            b.connect("clicked", lambda _b, k=key: self.on_accent(k))
            swatches.pack_start(b, False, False, 0)
            self.swatch_buttons[key] = b
        self._mark_accent(s["accent"])
        look.row("Accent colour", "Used for buttons, selections and switches.", swatches)

        self.section("Wallpaper")
        wall_card = self.card()
        self.walls = Gtk.FlowBox()
        self.walls.set_selection_mode(Gtk.SelectionMode.NONE)
        self.walls.set_max_children_per_line(4)
        self.walls.set_min_children_per_line(2)
        self.walls.set_column_spacing(10)
        self.walls.set_row_spacing(10)
        self.walls.set_homogeneous(True)
        row = Gtk.ListBoxRow()
        row.set_activatable(False)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.pack_start(self.walls, False, False, 0)
        add = button("Add picture…", self.add_picture)
        add.set_halign(Gtk.Align.START)
        box.pack_start(add, False, False, 0)
        row.add(box)
        wall_card.add(row)

        self.section("Animations")
        anim = self.card()
        anim.row("Animations", "Reduced and Off use less graphics power — good for older computers.",
                 Segmented(list(config.ANIMATION_LEVELS.items()), s["animations"], self.on_animations))

        self.section("Dock and top bar")
        bars = self.card()
        bars.row("Dock icon size", None,
                 Segmented([("40", "Small"), ("48", "Medium"), ("56", "Large")],
                           str(s["dock_icon_size"]), lambda k: config.update(dock_icon_size=int(k)) and None))
        bars.row("24-hour clock", None, switch(s["clock_24h"], lambda v: config.update(clock_24h=v)))
        bars.row("Show the date", None, switch(s["clock_show_date"], lambda v: config.update(clock_show_date=v)))
        bars.row("Battery percentage", "Only shown on computers with a battery.",
                 switch(s["battery_percent"], lambda v: config.update(battery_percent=v)))
        self._thumb_queue = []
        self.wall_buttons = {}
        self.load_walls()

    # ------------------------------------------------------------ appearance
    def on_mode(self, mode):
        config.update(mode=mode)
        ui.run_async(["lumen-theme", "apply"])

    def on_accent(self, key):
        self._mark_accent(key)
        config.update(accent=key)
        ui.run_async(["lumen-theme", "apply"])

    def _mark_accent(self, key):
        for k, b in self.swatch_buttons.items():
            ctx = b.get_style_context()
            if k == key:
                ctx.add_class("selected")
            else:
                ctx.remove_class("selected")

    def on_animations(self, level):
        config.update(animations=level)
        ui.run_async(["lumen-compositor", "restart"])

    # ------------------------------------------------------------ wallpaper
    def load_walls(self):
        for c in self.walls.get_children():
            self.walls.remove(c)
        self.wall_buttons = {}
        current = config.load()["wallpaper"]
        self._thumb_queue = []
        for path in config.wallpapers():
            b = Gtk.Button()
            b.set_relief(Gtk.ReliefStyle.NONE)
            ui.css_class(b, "wall-thumb")
            name = os.path.splitext(os.path.basename(path))[0].replace("-", " ").replace("_", " ").title()
            b.set_tooltip_text(name)
            placeholder = Gtk.Box()
            placeholder.set_size_request(THUMB_W, THUMB_H)
            b.add(placeholder)
            b.connect("clicked", lambda _b, p=path: self.set_wallpaper(p))
            if path == current:
                ui.css_class(b, "selected")
            self.walls.add(b)
            self.wall_buttons[path] = b
            self._thumb_queue.append((path, b))
        self.walls.show_all()
        GLib.idle_add(self._load_next_thumb)

    def _load_next_thumb(self):
        if not self._thumb_queue:
            return False
        path, b = self._thumb_queue.pop(0)
        pb = thumbnail(path)
        if pb is not None and b.get_child() is not None:
            b.remove(b.get_child())
            img = Gtk.Image.new_from_pixbuf(pb)
            b.add(img)
            img.show()
        return True

    def set_wallpaper(self, path):
        for p, b in self.wall_buttons.items():
            ctx = b.get_style_context()
            if p == path:
                ctx.add_class("selected")
            else:
                ctx.remove_class("selected")
        config.update(wallpaper=path)

    def add_picture(self):
        dlg = Gtk.FileChooserDialog(title="Add a wallpaper", transient_for=self.window,
                                    action=Gtk.FileChooserAction.OPEN)
        dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
        ok = dlg.add_button("Add", Gtk.ResponseType.OK)
        ui.css_class(ok, "suggested-action")
        flt = Gtk.FileFilter()
        flt.set_name("Pictures")
        flt.add_mime_type("image/png")
        flt.add_mime_type("image/jpeg")
        flt.add_mime_type("image/webp")
        flt.add_mime_type("image/svg+xml")
        dlg.add_filter(flt)
        pictures = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES)
        if pictures:
            dlg.set_current_folder(pictures)
        res = dlg.run()
        src = dlg.get_filename()
        dlg.destroy()
        if res != Gtk.ResponseType.OK or not src:
            return
        dest_dir = config.user_wallpaper_dir()
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, os.path.basename(src))
        if os.path.abspath(src) != os.path.abspath(dest):
            shutil.copyfile(src, dest)
        self.set_wallpaper(dest)
        self.load_walls()
