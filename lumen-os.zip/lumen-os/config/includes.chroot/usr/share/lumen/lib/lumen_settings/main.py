"""Lumen Settings - entry point.

    lumen-settings                  open Settings
    lumen-settings --page users     open a specific page
Pages: network, display, personalise, sound, users, privacy, updates, about
"""
import sys

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gio, GLib, Gtk  # noqa: E402

from lumen import config, ui  # noqa: E402

PAGES = [
    ("network", "Wi-Fi & Network", "network-wireless-symbolic", "network", "NetworkPage"),
    ("display", "Display", "video-display-symbolic", "display", "DisplayPage"),
    ("personalise", "Personalise", "preferences-desktop-wallpaper-symbolic", "personalise", "PersonalisePage"),
    ("sound", "Sound", "audio-speakers-symbolic", "sound", "SoundPage"),
    ("users", "Users", "system-users-symbolic", "users", "UsersPage"),
    ("privacy", "Privacy", "security-high-symbolic", "privacy", "PrivacyPage"),
    ("updates", "Updates", "software-update-available-symbolic", "updates", "UpdatesPage"),
    ("about", "About", "help-about-symbolic", "about", "AboutPage"),
]
ALIASES = {"wifi": "network", "appearance": "personalise", "personalize": "personalise",
           "wallpaper": "personalise", "accounts": "users", "update": "updates"}


class SettingsWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="Settings")
        self.set_default_size(960, 650)
        self.set_icon_name("emblem-system")
        self.pages = {}

        root = Gtk.Box()
        self.add(root)

        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        ui.css_class(side, "settings-sidebar")
        side.set_size_request(230, -1)
        title = ui.label("Settings", "sidebar-title")
        title.set_margin_top(18)
        title.set_margin_bottom(10)
        title.set_margin_start(20)
        side.pack_start(title, False, False, 0)
        self.list = Gtk.ListBox()
        self.list.set_selection_mode(Gtk.SelectionMode.BROWSE)
        for key, text, icon, _mod, _cls in PAGES:
            row = Gtk.ListBoxRow()
            row.key = key
            box = Gtk.Box(spacing=10)
            img = Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.MENU)
            img.set_pixel_size(16)
            box.pack_start(img, False, False, 0)
            box.pack_start(ui.label(text), True, True, 0)
            row.add(box)
            self.list.add(row)
        self.list.connect("row-selected", self.on_row)
        side.pack_start(self.list, True, True, 0)
        root.pack_start(side, False, False, 0)

        self.stack = Gtk.Stack()
        animated = config.load().get("animations") != "off"
        self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE if animated
                                       else Gtk.StackTransitionType.NONE)
        self.stack.set_transition_duration(140)
        root.pack_start(self.stack, True, True, 0)
        root.show_all()

    def on_row(self, _list, row):
        if row is not None:
            self.show_page(row.key, select=False)

    def show_page(self, key, select=True):
        key = ALIASES.get(key, key)
        entry = next((p for p in PAGES if p[0] == key), PAGES[0])
        key = entry[0]
        if key not in self.pages:
            module = __import__("lumen_settings.pages." + entry[3], fromlist=[entry[4]])
            page = getattr(module, entry[4])(self.get_application())
            page.show_all()
            self.pages[key] = page
            self.stack.add_named(page, key)
        self.stack.set_visible_child_name(key)
        self.pages[key].on_shown()
        if select:
            for row in self.list.get_children():
                if row.key == key:
                    self.list.select_row(row)
                    break


class SettingsApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.lumen.Settings",
                         flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.add_main_option("page", ord("p"), GLib.OptionFlags.NONE, GLib.OptionArg.STRING,
                             "Page to open", "PAGE")
        self.win = None

    def do_command_line(self, cmd):
        opts = cmd.get_options_dict().end().unpack()
        if self.win is None:
            self.win = SettingsWindow(self)
            first = True
        else:
            first = False
        page = opts.get("page")
        if page or first:
            self.win.show_page(page or "network")
        self.win.present()
        return 0


def main():
    GLib.set_prgname("lumen-settings")
    GLib.set_application_name("Settings")
    return SettingsApp().run(sys.argv)
