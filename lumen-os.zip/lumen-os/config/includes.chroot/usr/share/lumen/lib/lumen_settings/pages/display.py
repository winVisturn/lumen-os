"""Display: resolution (with a 15-second "keep these settings?" safety net),
text size and screen blanking."""
import os
import re
import shlex

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk  # noqa: E402

from lumen import config, ui  # noqa: E402
from ..widgets import Page, Segmented, button  # noqa: E402

DISPLAY_SCRIPT = os.path.join(config.CONFIG_DIR, "display.sh")


def parse_xrandr(text):
    outputs = []
    cur = None
    for line in text.splitlines():
        m = re.match(r"^(\S+) (connected|disconnected)( primary)?(?: (\d+)x(\d+)\+\d+\+\d+)?", line)
        if m:
            cur = None
            if m.group(2) == "connected":
                cur = {"name": m.group(1), "primary": bool(m.group(3)), "modes": [], "current": None,
                       "active": m.group(4) is not None}
                outputs.append(cur)
            continue
        if cur is not None:
            mm = re.match(r"^\s+(\d+x\d+)(i?)\s+(.*)$", line)
            if mm and not mm.group(2):
                mode = mm.group(1)
                if mode not in cur["modes"]:
                    cur["modes"].append(mode)
                if "*" in mm.group(3):
                    cur["current"] = mode
    return outputs


class DisplayPage(Page):
    title = "Display"

    def __init__(self, app):
        super().__init__(app)
        self.section("Screens")
        self.screens = self.card()
        self.note = ui.label("In a virtual machine, the screen resizes with the window when VM tools are installed.",
                             "row-subtitle", wrap=True)
        self.put(self.note)

        s = config.load()
        self.section("Text")
        text = self.card()
        text.row("Text size", "Makes text and controls bigger everywhere.",
                 Segmented([("1.0", "Default"), ("1.1", "Large"), ("1.25", "Larger")],
                           str(s.get("text_scale", 1.0)), self.on_text))

        self.section("Power saving")
        power = self.card()
        combo = Gtk.ComboBoxText()
        for mins, text_ in ((0, "Never"), (5, "5 minutes"), (10, "10 minutes"), (15, "15 minutes"),
                            (30, "30 minutes"), (60, "1 hour")):
            combo.append(str(mins), text_)
        combo.set_active_id(str(s.get("screen_off_minutes", 10)))
        combo.connect("changed", lambda c: self.on_blank(int(c.get_active_id())))
        power.row("Turn the screen off after", "When you're not using the computer.", combo)
        self.outputs = []

    def on_shown(self):
        ui.run_async(["xrandr", "--query"], self._got_xrandr)

    def _got_xrandr(self, ok, out, err):
        self.screens.clear()
        if not ok:
            self.screens.row("Couldn't read the screen setup", err.strip() or None)
            return
        self.outputs = parse_xrandr(out)
        for o in self.outputs:
            combo = Gtk.ComboBoxText()
            for mode in o["modes"]:
                w, h = mode.split("x")
                combo.append(mode, "%s × %s" % (w, h))
            if o["current"]:
                combo.set_active_id(o["current"])
            apply_btn = button("Apply", lambda o=o, c=combo: self.apply(o, c.get_active_id()))
            apply_btn.set_sensitive(False)
            combo.connect("changed", lambda c, o=o, b=apply_btn: b.set_sensitive(c.get_active_id() != o["current"]))
            box = Gtk.Box(spacing=6)
            box.pack_start(combo, False, False, 0)
            box.pack_start(apply_btn, False, False, 0)
            title = o["name"] + (" (main screen)" if o["primary"] or len(self.outputs) == 1 else "")
            self.screens.row(title, "Resolution", box,
                             prefix=Gtk.Image.new_from_icon_name("video-display-symbolic", Gtk.IconSize.DND))

    def apply(self, output, mode):
        if not mode or mode == output["current"]:
            return
        old = output["current"]
        ui.run_async(["xrandr", "--output", output["name"], "--mode", mode],
                     lambda ok, _o, err: self._applied(ok, err, output, old, mode))

    def _applied(self, ok, err, output, old, mode):
        if not ok:
            ui.run_async(["notify-send", "Couldn't change the resolution", err.strip()])
            self.on_shown()
            return
        dlg = Gtk.MessageDialog(transient_for=self.window, modal=True, message_type=Gtk.MessageType.QUESTION,
                                buttons=Gtk.ButtonsType.NONE, text="Keep these display settings?")
        dlg.add_button("Revert", Gtk.ResponseType.CANCEL)
        keep = dlg.add_button("Keep changes", Gtk.ResponseType.OK)
        ui.css_class(keep, "suggested-action")
        remaining = {"n": 15}

        def tick():
            dlg.format_secondary_text("Going back to the old settings in %d seconds." % remaining["n"])
            if remaining["n"] <= 0:
                dlg.response(Gtk.ResponseType.CANCEL)
                return False
            remaining["n"] -= 1
            return True
        tick()
        timer = GLib.timeout_add_seconds(1, tick)
        res = dlg.run()
        GLib.source_remove(timer) if remaining["n"] > 0 else None
        dlg.destroy()
        if res == Gtk.ResponseType.OK:
            output["current"] = mode
            self.save_script()
        elif old:
            ui.run_async(["xrandr", "--output", output["name"], "--mode", old])
        GLib.timeout_add(600, lambda: (self.on_shown(), False)[1])

    def save_script(self):
        os.makedirs(config.CONFIG_DIR, exist_ok=True)
        lines = ["#!/bin/sh", "# Saved by Settings > Display"]
        for o in self.outputs:
            if o["current"]:
                lines.append("xrandr --output %s --mode %s" % (shlex.quote(o["name"]), shlex.quote(o["current"])))
        with open(DISPLAY_SCRIPT, "w") as f:
            f.write("\n".join(lines) + "\n")

    def on_text(self, key):
        config.update(text_scale=float(key))
        ui.run_async(["lumen-theme", "apply"])

    def on_blank(self, minutes):
        config.update(screen_off_minutes=minutes)
        ui.run_async(["lumen-theme", "apply"])
