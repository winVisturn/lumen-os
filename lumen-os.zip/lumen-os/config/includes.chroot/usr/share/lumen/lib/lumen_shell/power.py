"""Shut down / restart / log out confirmation (dims the screen, 60 s countdown)."""
import subprocess

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, GLib, Gtk  # noqa: E402

from lumen import apps, ui  # noqa: E402

ACTIONS = {
    "shutdown": ("system-shutdown-symbolic", "Shut down this computer?", "Shut down",
                 "Shutting down automatically in %d seconds.", ["systemctl", "poweroff"]),
    "restart": ("view-refresh-symbolic", "Restart this computer?", "Restart",
                "Restarting automatically in %d seconds.", ["systemctl", "reboot"]),
    "logout": ("system-log-out-symbolic", "Log out?", "Log out",
               "Logging out automatically in %d seconds. Unsaved work may be lost.", ["openbox", "--exit"]),
}
COUNTDOWN = 60


class Power:
    def __init__(self, shell):
        self.shell = shell
        self.win = None

    def run(self, action):
        argv = {"suspend": ["systemctl", "suspend"],
                "shutdown": ACTIONS["shutdown"][4],
                "restart": ACTIONS["restart"][4],
                "logout": ACTIONS["logout"][4]}[action]
        if action == "suspend":
            # Lock first so the computer wakes to the login screen.
            subprocess.Popen(["dm-tool", "lock"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            GLib.timeout_add(700, lambda: (apps.spawn(argv), False)[1])
            return
        if action == "logout":
            subprocess.Popen(["lumen-compositor", "stop"])
        try:
            res = subprocess.run(argv, capture_output=True, text=True, timeout=20)
            if res.returncode != 0:
                apps.notify("Couldn't %s" % ACTIONS[action][2].lower(),
                            res.stderr.strip() or "The system refused the request.")
        except Exception as e:
            apps.notify("Couldn't %s" % ACTIONS[action][2].lower(), str(e))

    def ask(self, action=None):
        if self.win is not None:
            self.win.destroy()
        self.win = PowerDialog(self, action or "shutdown")
        self.win.present_now()


class PowerDialog(Gtk.Window):
    def __init__(self, power, action):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.power = power
        self.action = action
        self.remaining = COUNTDOWN
        self.set_title("lumen-power")
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)

        overlay = Gtk.Box()
        ui.css_class(overlay, "power-overlay")
        self.add(overlay)
        ui.setup_transparency(self, overlay)

        icon_name, title, verb, sub, _argv = ACTIONS[action]
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        ui.css_class(card, "power-card")
        card.set_halign(Gtk.Align.CENTER)
        card.set_valign(Gtk.Align.CENTER)
        card.set_size_request(380, -1)
        img = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
        img.set_pixel_size(36)
        card.pack_start(img, False, False, 0)
        card.pack_start(ui.label(title, "power-title", xalign=0.5), False, False, 0)
        self.sub = ui.label("", "dim-label", xalign=0.5, wrap=True)
        self.sub_fmt = sub
        card.pack_start(self.sub, False, False, 0)

        buttons = Gtk.Box(spacing=8, homogeneous=True)
        buttons.set_margin_top(10)
        cancel = Gtk.Button(label="Cancel")
        cancel.connect("clicked", lambda *_a: self.close_dialog())
        buttons.pack_start(cancel, True, True, 0)
        # Offer the related actions too (e.g. Restart next to Shut down).
        others = [a for a in ("restart", "shutdown") if a != action] if action != "logout" else []
        for other in others:
            b = Gtk.Button(label=ACTIONS[other][2])
            b.connect("clicked", lambda _b, o=other: self.confirm(o))
            buttons.pack_start(b, True, True, 0)
        ok = Gtk.Button(label=verb)
        ui.css_class(ok, "suggested-action" if action != "shutdown" else "destructive-action")
        ok.connect("clicked", lambda *_a: self.confirm(action))
        buttons.pack_start(ok, True, True, 0)
        card.pack_start(buttons, False, False, 0)
        overlay.set_center_widget(card)
        self.card = card
        self.ok_button = ok

        self.connect("key-press-event", self._on_key)
        self.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.connect("button-press-event", self._on_click)
        self._timer = 0
        self._tick()
        self._timer = GLib.timeout_add_seconds(1, self._tick)

    def present_now(self):
        g = ui.primary_geometry()
        self.move(g.x, g.y)
        self.set_default_size(g.width, g.height)
        self.resize(g.width, g.height)
        self.show_all()
        self.set_opacity(0.0)
        self.present()
        self.ok_button.grab_focus()
        ui.Anim(self, 160, lambda t: self.set_opacity(t),
                enabled=self.power.shell.settings.get("animations") != "off")

    def _tick(self):
        self.sub.set_text(self.sub_fmt % self.remaining)
        if self.remaining <= 0:
            self.confirm(self.action)
            return False
        self.remaining -= 1
        return True

    def _on_click(self, _w, event):
        a = self.card.get_allocation()
        inside = a.x <= event.x <= a.x + a.width and a.y <= event.y <= a.y + a.height
        if not inside:
            self.close_dialog()
        return False

    def _on_key(self, _w, event):
        if event.keyval == Gdk.KEY_Escape:
            self.close_dialog()
            return True
        return False

    def confirm(self, action):
        self.stop_timer()
        self.hide()
        GLib.timeout_add(150, lambda: (self.power.run(action), False)[1])
        self.destroy()
        self.power.win = None

    def stop_timer(self):
        if self._timer:
            GLib.source_remove(self._timer)
            self._timer = 0

    def close_dialog(self):
        self.stop_timer()

        def done():
            self.destroy()
            self.power.win = None
        ui.Anim(self, 120, lambda t: self.set_opacity(1 - t), done,
                enabled=self.power.shell.settings.get("animations") != "off")
