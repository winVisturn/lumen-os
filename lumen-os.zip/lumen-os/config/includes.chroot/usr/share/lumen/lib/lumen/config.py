"""Per-user settings for Lumen OS, stored in ~/.config/lumen/settings.json.

Pure Python (no GTK) so it can be used by the shell, Settings and the
theme engine alike.
"""
import json
import os
import tempfile

DATA_DIR = os.environ.get("LUMEN_DATA", "/usr/share/lumen")
BACKGROUND_DIRS = ["/usr/share/backgrounds/lumen"]

CONFIG_HOME = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
CONFIG_DIR = os.path.join(CONFIG_HOME, "lumen")
SETTINGS_FILE = os.path.join(CONFIG_DIR, "settings.json")

DEFAULT_DOCK = [
    "thunar.desktop",
    "firefox-esr.desktop",
    "xfce4-terminal.desktop",
    "org.xfce.Parole.desktop",
    "org.xfce.mousepad.desktop",
    "lumen-settings.desktop",
]

DEFAULTS = {
    "mode": "light",            # light | softdim | dusk
    "accent": "teal",           # see ACCENTS
    "wallpaper": "/usr/share/backgrounds/lumen/valley.png",
    "animations": "full",       # full | reduced | off
    "dock_icon_size": 48,       # 40 | 48 | 56
    "dock_apps": DEFAULT_DOCK,
    "clock_24h": True,
    "clock_show_date": True,
    "battery_percent": True,
    "text_scale": 1.0,          # 1.0 | 1.1 | 1.25
    "screen_off_minutes": 10,   # 0 = never
    "remember_recent": True,
}

# name -> (label, colour)
ACCENTS = {
    "teal": ("Teal", "#2E6E7E"),
    "green": ("Green", "#5E8A55"),
    "purple": ("Purple", "#8E6FA8"),
    "orange": ("Orange", "#C46F49"),
    "blue": ("Blue", "#55679E"),
}

MODES = {
    "light": "Light",
    "softdim": "Soft dim",
    "dusk": "Dusk",
}

ANIMATION_LEVELS = {
    "full": "Full",
    "reduced": "Reduced",
    "off": "Off",
}


def load():
    data = dict(DEFAULTS)
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            stored = json.load(f)
        if isinstance(stored, dict):
            for key, value in stored.items():
                if key in DEFAULTS:
                    data[key] = value
    except (OSError, ValueError):
        pass
    if data["mode"] not in MODES:
        data["mode"] = DEFAULTS["mode"]
    if data["accent"] not in ACCENTS:
        data["accent"] = DEFAULTS["accent"]
    if data["animations"] not in ANIMATION_LEVELS:
        data["animations"] = DEFAULTS["animations"]
    if not isinstance(data["dock_apps"], list):
        data["dock_apps"] = list(DEFAULT_DOCK)
    return data


def exists():
    return os.path.exists(SETTINGS_FILE)


def save(data):
    """Atomically write settings (so the shell never reads half a file)."""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    clean = {k: data.get(k, v) for k, v in DEFAULTS.items()}
    fd, tmp = tempfile.mkstemp(dir=CONFIG_DIR, prefix=".settings-", suffix=".json")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(clean, f, indent=2)
        f.write("\n")
    os.replace(tmp, SETTINGS_FILE)


def update(**changes):
    data = load()
    data.update(changes)
    save(data)
    return data


def wallpapers():
    """Built-in wallpapers plus anything in ~/Pictures/Wallpapers."""
    found = []
    dirs = list(BACKGROUND_DIRS) + [user_wallpaper_dir()]
    for d in dirs:
        try:
            names = sorted(os.listdir(d))
        except OSError:
            continue
        for n in names:
            if n.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".svg")):
                found.append(os.path.join(d, n))
    return found


def user_wallpaper_dir():
    pictures = os.path.expanduser("~/Pictures")
    try:
        import subprocess
        out = subprocess.run(["xdg-user-dir", "PICTURES"], capture_output=True,
                             text=True, timeout=2).stdout.strip()
        if out and out != os.path.expanduser("~"):
            pictures = out
    except Exception:
        pass
    return os.path.join(pictures, "Wallpapers")
