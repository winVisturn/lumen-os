"""Sound: output/input device, volume and mute (PipeWire through pactl)."""
import json
import re

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk  # noqa: E402

from lumen import ui  # noqa: E402
from ..widgets import Page  # noqa: E402


class SoundPage(Page):
    title = "Sound"

    def __init__(self, app):
        super().__init__(app)
        self.section("Output")
        out = self.card()
        self.out_combo = Gtk.ComboBoxText()
        self.out_combo.connect("changed", lambda c: self._set_default("sink", c.get_active_id()))
        out.row("Play sound through", None, self.out_combo)
        self.out_scale, self.out_mute = self._volume_row(out, "Volume", "sink")

        self.section("Input")
        inp = self.card()
        self.in_combo = Gtk.ComboBoxText()
        self.in_combo.connect("changed", lambda c: self._set_default("source", c.get_active_id()))
        inp.row("Microphone", None, self.in_combo)
        self.in_scale, self.in_mute = self._volume_row(inp, "Input volume", "source")
        self._loading = False

    def _volume_row(self, card, title, kind):
        box = Gtk.Box(spacing=8)
        scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        scale.set_draw_value(False)
        scale.set_size_request(260, -1)
        target = "@DEFAULT_SINK@" if kind == "sink" else "@DEFAULT_SOURCE@"
        scale.connect("value-changed", lambda s: None if self._loading else ui.run_async(
            ["pactl", "set-%s-volume" % kind, target, "%d%%" % int(s.get_value())]))
        mute = Gtk.Switch()
        mute.set_tooltip_text("Sound on")
        mute.connect("state-set", lambda _s, state: None if self._loading else ui.run_async(
            ["pactl", "set-%s-mute" % kind, target, "0" if state else "1"]))
        box.pack_start(scale, True, True, 0)
        box.pack_start(mute, False, False, 0)
        card.row(title, None, box)
        return scale, mute

    def on_shown(self):
        ui.run_async(["pactl", "-f", "json", "list", "sinks"], lambda ok, o, e: self._got_devices("sink", ok, o))
        ui.run_async(["pactl", "-f", "json", "list", "sources"], lambda ok, o, e: self._got_devices("source", ok, o))

    def _got_devices(self, kind, ok, out):
        combo = self.out_combo if kind == "sink" else self.in_combo
        try:
            devices = json.loads(out) if ok else []
        except ValueError:
            devices = []
        if kind == "source":
            devices = [d for d in devices if not d.get("name", "").endswith(".monitor")]
        self._loading = True
        combo.remove_all()
        for d in devices:
            combo.append(d.get("name", ""), d.get("description") or d.get("name", "?"))
        combo.set_sensitive(bool(devices))
        if not devices:
            combo.append("none", "No devices found")
            combo.set_active_id("none")
        self._loading = False
        ui.run_async(["pactl", "get-default-%s" % kind],
                     lambda ok2, o, e: self._got_default(kind, devices, o.strip()))

    def _got_default(self, kind, devices, name):
        combo = self.out_combo if kind == "sink" else self.in_combo
        scale = self.out_scale if kind == "sink" else self.in_scale
        mute = self.out_mute if kind == "sink" else self.in_mute
        self._loading = True
        if name:
            combo.set_active_id(name)
        dev = next((d for d in devices if d.get("name") == name), None)
        if dev:
            vols = dev.get("volume", {})
            pcts = []
            for ch in vols.values():
                m = re.match(r"(\d+)%", str(ch.get("value_percent", "")).strip())
                if m:
                    pcts.append(int(m.group(1)))
            if pcts:
                scale.set_value(min(100, max(pcts)))
            mute.set_active(not dev.get("mute", False))
        self._loading = False

    def _set_default(self, kind, name):
        if self._loading or not name or name == "none":
            return
        ui.run_async(["pactl", "set-default-%s" % kind, name],
                     lambda *_a: GLib.timeout_add(300, lambda: (self.on_shown(), False)[1]))
