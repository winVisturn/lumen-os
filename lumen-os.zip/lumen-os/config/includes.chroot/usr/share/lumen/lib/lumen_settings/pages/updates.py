"""Updates: check for and install software updates (through lpm / apt)."""
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gio, GLib, Gtk  # noqa: E402

from lumen import ui  # noqa: E402
from ..widgets import Page, button, mono_textview  # noqa: E402


class UpdatesPage(Page):
    title = "Updates"

    def __init__(self, app):
        super().__init__(app)
        self.section("Software updates")
        top = self.card()
        status_box = Gtk.Box(spacing=8)
        self.spinner = Gtk.Spinner()
        self.check_btn = button("Check for updates", self.check)
        self.install_btn = button("Install updates", self.install, "suggested-action")
        self.install_btn.set_no_show_all(True)
        status_box.pack_start(self.spinner, False, False, 0)
        status_box.pack_start(self.check_btn, False, False, 0)
        status_box.pack_start(self.install_btn, False, False, 0)
        self.status_row = top.row("Lumen OS 1", "Updates keep your computer safe. Check whenever you like.",
                                  status_box,
                                  prefix=Gtk.Image.new_from_icon_name("lumen-logo", Gtk.IconSize.DND))

        self.list_title = self.section("Available")
        self.list_title.set_no_show_all(True)
        self.list = self.card()
        self.list.set_no_show_all(True)

        self.details = Gtk.Expander(label="Details")
        self.log = mono_textview()
        sw = Gtk.ScrolledWindow()
        sw.set_min_content_height(200)
        sw.add(self.log)
        self.details.add(sw)
        self.put(self.details)
        self.busy = False

    def _status(self, title, sub):
        self.status_row.title_label.set_text(title)
        self.status_row.subtitle_label.set_text(sub)
        self.status_row.subtitle_label.show()

    def _append(self, text):
        buf = self.log.get_buffer()
        buf.insert(buf.get_end_iter(), text)
        self.log.scroll_to_iter(buf.get_end_iter(), 0, False, 0, 0)

    def _set_busy(self, busy):
        self.busy = busy
        self.check_btn.set_sensitive(not busy)
        self.install_btn.set_sensitive(not busy)
        (self.spinner.start if busy else self.spinner.stop)()

    def stream(self, argv, done):
        """Run argv and show its output live in Details."""
        try:
            proc = Gio.Subprocess.new(argv, Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_MERGE)
        except GLib.Error as e:
            self._append(e.message + "\n")
            done(False)
            return
        stream = Gio.DataInputStream.new(proc.get_stdout_pipe())

        def got(s, res):
            try:
                line, _n = s.read_line_finish_utf8(res)
            except GLib.Error:
                line = None
            if line is None:
                proc.wait_async(None, lambda p, r: (p.wait_finish(r), done(p.get_successful())))
                return
            self._append(line + "\n")
            s.read_line_async(GLib.PRIORITY_DEFAULT, None, got)
        stream.read_line_async(GLib.PRIORITY_DEFAULT, None, got)

    def check(self):
        if self.busy:
            return
        self._set_busy(True)
        self._status("Checking for updates…", "This needs an administrator password.")
        self._append("$ lpm update\n")
        self.stream(["pkexec", "/usr/bin/lpm", "update"], self._checked)

    def _checked(self, ok):
        if not ok:
            self._set_busy(False)
            self._status("Couldn't check for updates", "Check your internet connection, then try again.")
            return
        ui.run_async(["/usr/bin/lpm", "list-updates"], self._got_list)

    def _got_list(self, _ok, out, _err):
        self._set_busy(False)
        pkgs = [l.split(" ", 1) for l in out.splitlines() if l.strip()]
        self.list.clear()
        if not pkgs:
            self._status("Lumen OS is up to date", "No updates right now.")
            self.install_btn.hide()
            self.list.hide()
            self.list_title.hide()
            return
        n = len(pkgs)
        self._status("%d update%s available" % (n, "" if n == 1 else "s"), "Install them now or later.")
        for p in pkgs[:200]:
            self.list.row(p[0], ("Version " + p[1]) if len(p) > 1 else None)
        if n > 200:
            self.list.row("… and %d more" % (n - 200), None)
        self.install_btn.show()
        self.list_title.show()
        self.list.show()

    def install(self):
        if self.busy:
            return
        self._set_busy(True)
        self.details.set_expanded(True)
        self._status("Installing updates…", "Please keep the computer on.")
        self._append("$ lpm upgrade -y\n")
        self.stream(["pkexec", "/usr/bin/lpm", "upgrade", "-y"], self._installed)

    def _installed(self, ok):
        self._set_busy(False)
        if ok:
            self._status("Updates installed", "Restart if the kernel or system libraries were updated.")
            self.install_btn.hide()
            self.list.hide()
            self.list_title.hide()
        else:
            self._status("Some updates didn't install", "See Details for what went wrong.")
