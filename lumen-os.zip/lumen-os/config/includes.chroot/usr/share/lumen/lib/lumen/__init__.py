"""Shared code for Lumen OS (shell, settings and theme engine)."""
VERSION = "1"
PRODUCT = "Lumen OS"
