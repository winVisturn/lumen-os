"""Small GTK helpers shared by the shell and Settings."""
import cairo
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk  # noqa: E402


def ease_out(t):
    return 1 - (1 - t) ** 3


def ease_in_out(t):
    return 4 * t * t * t if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2


class Anim:
    """Frame-clock driven tween: step(progress 0..1) is called every frame."""

    def __init__(self, widget, ms, step, done=None, ease=ease_out, enabled=True):
        self.widget, self.ms, self.step, self.done, self.ease = widget, ms, step, done, ease
        self._id = None
        self._start = None
        if not enabled or ms <= 0 or not widget.get_realized():
            step(1.0)
            if done:
                done()
            return
        self._id = widget.add_tick_callback(self._tick)

    def _tick(self, widget, clock):
        now = clock.get_frame_time()
        if self._start is None:
            self._start = now
        t = min(1.0, (now - self._start) / (self.ms * 1000.0))
        self.step(self.ease(t))
        if t >= 1.0:
            self._id = None
            if self.done:
                self.done()
            return GLib.SOURCE_REMOVE
        return GLib.SOURCE_CONTINUE

    def cancel(self):
        if self._id is not None:
            self.widget.remove_tick_callback(self._id)
            self._id = None


def _clear(_widget, cr):
    cr.set_source_rgba(0, 0, 0, 0)
    cr.set_operator(cairo.OPERATOR_SOURCE)
    cr.paint()
    cr.set_operator(cairo.OPERATOR_OVER)
    return False


def setup_transparency(win, styled_widget):
    """Give a window an alpha channel when a compositor is running.
    Without one, add the 'solid' style class so it is drawn opaque."""
    screen = win.get_screen()
    win.set_app_paintable(True)
    win.connect("draw", _clear)

    def apply():
        composited = screen.is_composited()
        visual = screen.get_rgba_visual() if composited else None
        ctx = styled_widget.get_style_context()
        if composited:
            ctx.remove_class("solid")
        else:
            ctx.add_class("solid")
        target = visual or screen.get_system_visual()
        if win.get_visual() != target:
            was_visible = win.get_visible()
            if win.get_realized():
                win.hide()
                win.unrealize()
            win.set_visual(target)
            if was_visible:
                win.show_all()

    apply()
    screen.connect("composited-changed", lambda *_a: GLib.timeout_add(300, lambda: (apply(), False)[1]))


def primary_geometry():
    display = Gdk.Display.get_default()
    mon = display.get_primary_monitor() or display.get_monitor(0)
    return mon.get_geometry()


def run_async(argv, callback=None, stdin_text=None):
    """Run a command without blocking the UI. callback(ok, stdout, stderr)."""
    flags = Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE
    if stdin_text is not None:
        flags |= Gio.SubprocessFlags.STDIN_PIPE
    try:
        proc = Gio.Subprocess.new(argv, flags)
    except GLib.Error as e:
        if callback:
            callback(False, "", e.message)
        return None

    def finish(p, res):
        try:
            _ok, out, err = p.communicate_utf8_finish(res)
            ok = p.get_successful()
        except GLib.Error as e:
            ok, out, err = False, "", e.message
        if callback:
            callback(ok, out or "", err or "")

    proc.communicate_utf8_async(stdin_text, None, finish)
    return proc


def css_class(widget, *names):
    ctx = widget.get_style_context()
    for n in names:
        ctx.add_class(n)
    return widget


def label(text, *classes, xalign=0.0, wrap=False, markup=False, ellipsize=False):
    lbl = Gtk.Label()
    if markup:
        lbl.set_markup(text)
    else:
        lbl.set_text(text)
    lbl.set_xalign(xalign)
    if wrap:
        lbl.set_line_wrap(True)
    if ellipsize:
        from gi.repository import Pango
        lbl.set_ellipsize(Pango.EllipsizeMode.END)
    css_class(lbl, *classes)
    return lbl


def settings_watcher(callback):
    """Call callback() (debounced) whenever ~/.config/lumen/settings.json changes."""
    from . import config
    import os
    os.makedirs(config.CONFIG_DIR, exist_ok=True)
    directory = Gio.File.new_for_path(config.CONFIG_DIR)
    monitor = directory.monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, None)
    pending = {"id": 0}

    def fire():
        pending["id"] = 0
        callback()
        return False

    def changed(_m, f, other, _event):
        names = {f.get_basename() if f else "", other.get_basename() if other else ""}
        if "settings.json" in names:
            if pending["id"]:
                GLib.source_remove(pending["id"])
            pending["id"] = GLib.timeout_add(150, fire)

    monitor.connect("changed", changed)
    return monitor
