"""Building blocks for Settings pages (cards, rows, segmented buttons, dialogs)."""
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk, Pango  # noqa: E402

from lumen import ui  # noqa: E402


class Page(Gtk.Box):
    """A titled, scrollable settings page."""
    title = "Page"

    def __init__(self, app):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.app = app
        ui.css_class(self, "settings-page")
        header = Gtk.Box(spacing=8)
        ui.css_class(header, "page-header")
        header.set_size_request(-1, 52)
        self.title_label = ui.label(self.title, "page-title")
        self.title_label.set_margin_start(24)
        header.pack_start(self.title_label, False, False, 0)
        self.header_end = Gtk.Box(spacing=6)
        self.header_end.set_margin_end(18)
        header.pack_end(self.header_end, False, False, 0)
        self.pack_start(header, False, False, 0)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        ui.css_class(scroller, "settings-page")
        self.body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.body.set_margin_top(20)
        self.body.set_margin_bottom(28)
        self.body.set_margin_start(24)
        self.body.set_margin_end(24)
        clamp = Gtk.Box()
        clamp.set_halign(Gtk.Align.FILL)
        clamp.pack_start(self.body, True, True, 0)
        scroller.add(clamp)
        self.pack_start(scroller, True, True, 0)

    def put(self, widget, expand=False):
        self.body.pack_start(widget, expand, expand, 0)
        return widget

    def section(self, text):
        lbl = ui.label(text.upper(), "section-title")
        lbl.set_margin_top(10)
        return self.put(lbl)

    def card(self):
        return self.put(Card())

    def on_shown(self):
        """Called every time the page becomes visible."""

    @property
    def window(self):
        return self.get_toplevel()


class Card(Gtk.ListBox):
    def __init__(self):
        super().__init__()
        ui.css_class(self, "card")
        self.set_selection_mode(Gtk.SelectionMode.NONE)
        self.connect("row-activated", lambda _l, row: getattr(row, "on_activate", lambda: None)())

    def row(self, title, subtitle=None, widget=None, prefix=None, activate=None):
        row = Gtk.ListBoxRow()
        row.set_activatable(activate is not None)
        if activate is not None:
            row.on_activate = activate
            ui.css_class(row, "activatable")
        box = Gtk.Box(spacing=12)
        if prefix is not None:
            prefix.set_valign(Gtk.Align.CENTER)
            box.pack_start(prefix, False, False, 0)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        texts.set_valign(Gtk.Align.CENTER)
        row.title_label = ui.label(title, "row-title", ellipsize=True)
        texts.pack_start(row.title_label, False, False, 0)
        row.subtitle_label = ui.label(subtitle or "", "row-subtitle", wrap=True)
        row.subtitle_label.set_no_show_all(not subtitle)
        texts.pack_start(row.subtitle_label, False, False, 0)
        box.pack_start(texts, True, True, 0)
        if widget is not None:
            widget.set_valign(Gtk.Align.CENTER)
            box.pack_end(widget, False, False, 0)
        row.add(box)
        row.end_box = box
        self.add(row)
        row.show_all()
        return row

    def clear(self):
        for c in self.get_children():
            self.remove(c)
            c.destroy()


def set_subtitle(row, text):
    row.subtitle_label.set_text(text or "")
    row.subtitle_label.set_no_show_all(False)
    row.subtitle_label.set_visible(bool(text))


class Segmented(Gtk.Box):
    """A row of mutually exclusive buttons (like a pill switcher)."""

    def __init__(self, options, current, on_change):
        super().__init__(spacing=2)
        ui.css_class(self, "segmented")
        self.buttons = {}
        self._busy = False
        self.on_change = on_change
        for key, text in options:
            b = Gtk.ToggleButton(label=text)
            b.set_relief(Gtk.ReliefStyle.NONE)
            b.connect("toggled", self._toggled, key)
            self.pack_start(b, False, False, 0)
            self.buttons[key] = b
        self.set_current(current)

    def set_current(self, key):
        self._busy = True
        for k, b in self.buttons.items():
            b.set_active(k == key)
        self._busy = False
        self.current = key

    def _toggled(self, button, key):
        if self._busy:
            return
        if not button.get_active():
            if key == self.current:
                self._busy = True
                button.set_active(True)
                self._busy = False
            return
        self.set_current(key)
        self.on_change(key)


def switch(active, on_change):
    sw = Gtk.Switch()
    sw.set_active(bool(active))
    sw.connect("notify::active", lambda s, _p: on_change(s.get_active()))
    return sw


def button(text, on_click, style=None):
    b = Gtk.Button(label=text)
    if style:
        ui.css_class(b, style)
    b.connect("clicked", lambda *_a: on_click())
    return b


def avatar(name, seed, big=False):
    letter = (name.strip()[:1] or "?").upper()
    lbl = Gtk.Label(label=letter)
    lbl.set_xalign(0.5)
    lbl.set_yalign(0.5)
    ui.css_class(lbl, "avatar", "avatar-%d" % (sum(map(ord, seed)) % 6))
    if big:
        ui.css_class(lbl, "big")
    return lbl


def message(parent, title, text, kind=Gtk.MessageType.INFO):
    dlg = Gtk.MessageDialog(transient_for=parent, modal=True, message_type=kind,
                            buttons=Gtk.ButtonsType.OK, text=title)
    if text:
        dlg.format_secondary_text(text)
    dlg.run()
    dlg.destroy()


def confirm(parent, title, text, ok_label, destructive=False):
    dlg = Gtk.MessageDialog(transient_for=parent, modal=True, message_type=Gtk.MessageType.QUESTION,
                            buttons=Gtk.ButtonsType.NONE, text=title)
    if text:
        dlg.format_secondary_text(text)
    dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
    ok = dlg.add_button(ok_label, Gtk.ResponseType.OK)
    ui.css_class(ok, "destructive-action" if destructive else "suggested-action")
    res = dlg.run()
    dlg.destroy()
    return res == Gtk.ResponseType.OK


class FormDialog(Gtk.Dialog):
    """A small dialog with labelled fields and a primary button."""

    def __init__(self, parent, title, ok_label):
        super().__init__(title=title, transient_for=parent, modal=True)
        self.set_default_size(400, -1)
        self.set_resizable(False)
        self.add_button("Cancel", Gtk.ResponseType.CANCEL)
        self.ok = self.add_button(ok_label, Gtk.ResponseType.OK)
        ui.css_class(self.ok, "suggested-action")
        self.set_default_response(Gtk.ResponseType.OK)
        area = self.get_content_area()
        area.set_border_width(18)
        area.set_spacing(6)
        self.grid = Gtk.Grid(row_spacing=10, column_spacing=12)
        area.pack_start(self.grid, True, True, 0)
        self.rows = 0
        self.hint = ui.label("", "row-subtitle", wrap=True)
        self.hint.set_margin_top(6)
        self.hint.set_max_width_chars(46)
        area.pack_end(self.hint, False, False, 0)

    def field(self, text, widget):
        lbl = ui.label(text, xalign=1.0)
        self.grid.attach(lbl, 0, self.rows, 1, 1)
        widget.set_hexpand(True)
        self.grid.attach(widget, 1, self.rows, 1, 1)
        self.rows += 1
        if isinstance(widget, Gtk.Entry):
            widget.set_activates_default(True)
        return widget

    def note(self, text):
        lbl = ui.label(text, "row-subtitle", wrap=True)
        lbl.set_max_width_chars(46)
        self.grid.attach(lbl, 0, self.rows, 2, 1)
        self.rows += 1
        return lbl


def password_entry(placeholder=""):
    e = Gtk.Entry()
    e.set_visibility(False)
    e.set_input_purpose(Gtk.InputPurpose.PASSWORD)
    e.set_placeholder_text(placeholder)
    return e


def password_strength(pw):
    """Very small, honest strength hint."""
    if not pw:
        return ""
    score = 0
    score += len(pw) >= 8
    score += len(pw) >= 12
    score += any(c.isdigit() for c in pw)
    score += any(c.isupper() for c in pw) and any(c.islower() for c in pw)
    score += any(not c.isalnum() for c in pw)
    if len(pw) < 6:
        return "Too short — use at least 6 characters."
    return ["Weak password", "Weak password", "Okay password", "Good password", "Strong password",
            "Very strong password"][score]


def mono_textview():
    tv = Gtk.TextView()
    tv.set_editable(False)
    tv.set_cursor_visible(False)
    tv.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
    tv.set_left_margin(10)
    tv.set_right_margin(10)
    tv.set_top_margin(8)
    tv.set_bottom_margin(8)
    ui.css_class(tv, "mono", "log-view")
    return tv


def idle(fn, *args):
    GLib.idle_add(lambda: (fn(*args), False)[1])


def ellipsize(lbl):
    lbl.set_ellipsize(Pango.EllipsizeMode.END)
    return lbl
