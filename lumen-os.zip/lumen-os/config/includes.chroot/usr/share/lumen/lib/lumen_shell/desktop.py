"""The desktop: wallpaper (with a cross-fade when it changes) and ~/Desktop icons."""
import os

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk, Pango  # noqa: E402

from lumen import apps, palette, ui  # noqa: E402

ICON = 48
ATTRS = ",".join(["standard::name", "standard::display-name", "standard::icon", "standard::is-hidden",
                  "standard::is-backup", "standard::type", "standard::content-type", "thumbnail::path"])


def desktop_dir():
    d = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DESKTOP)
    if not d or d == os.path.expanduser("~"):
        d = os.path.expanduser("~/Desktop")
    os.makedirs(d, exist_ok=True)
    return d


class Desktop(Gtk.Window):
    def __init__(self, shell):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.shell = shell
        self.set_title("lumen-desktop")
        self.set_decorated(False)
        self.set_type_hint(Gdk.WindowTypeHint.DESKTOP)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_below(True)
        self.stick()
        ui.css_class(self, "lumen-desktop")

        self.wall_path = None
        self.wall_src = None        # full-size pixbuf
        self.wall_scaled = None     # (w, h, pixbuf) cover-scaled
        self.old_scaled = None      # previous wallpaper during cross-fade
        self.fade = 1.0
        self._fade_anim = None

        overlay = Gtk.Overlay()
        self.add(overlay)
        self.area = Gtk.DrawingArea()
        self.area.connect("draw", self.on_draw)
        self.area.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.area.connect("button-press-event", self.on_background_press)
        overlay.add(self.area)

        self.grid = Gtk.FlowBox()
        ui.css_class(self.grid, "desk-grid")
        self.grid.set_orientation(Gtk.Orientation.VERTICAL)
        self.grid.set_direction(Gtk.TextDirection.RTL)   # first column on the right
        self.grid.set_halign(Gtk.Align.START)
        self.grid.set_valign(Gtk.Align.START)
        self.grid.set_margin_top(44)
        self.grid.set_margin_start(18)
        self.grid.set_margin_bottom(int(shell.settings.get("dock_icon_size", 48)) + 50)
        self.grid.set_column_spacing(4)
        self.grid.set_row_spacing(4)
        self.grid.set_homogeneous(True)
        self.grid.set_selection_mode(Gtk.SelectionMode.MULTIPLE)
        self.grid.set_activate_on_single_click(False)
        self.grid.connect("child-activated", self.on_activate)
        overlay.add_overlay(self.grid)
        overlay.set_overlay_pass_through(self.grid, False)

        self.dir = desktop_dir()
        self._monitor = Gio.File.new_for_path(self.dir).monitor_directory(Gio.FileMonitorFlags.WATCH_MOVES, None)
        self._monitor.connect("changed", lambda *_a: self.queue_refresh())
        self._refresh_id = 0

        self.connect("key-press-event", self.on_key)
        self.load_wallpaper(animate=False)
        self.refresh()

    # ------------------------------------------------------------ geometry
    def place(self):
        g = ui.primary_geometry()
        self.move(g.x, g.y)
        self.set_size_request(g.width, g.height)
        self.resize(g.width, g.height)
        self.wall_scaled = None
        self.queue_draw()

    def reload(self):
        self.grid.set_margin_bottom(int(self.shell.settings.get("dock_icon_size", 48)) + 50)
        if self.shell.settings.get("wallpaper") != self.wall_path:
            self.load_wallpaper(animate=True)
        else:
            self.queue_draw()

    # ------------------------------------------------------------ wallpaper
    def load_wallpaper(self, animate=True):
        path = self.shell.settings.get("wallpaper")
        self.wall_path = path
        try:
            src = GdkPixbuf.Pixbuf.new_from_file(path) if path else None
        except GLib.Error:
            src = None
        previous = self.wall_scaled
        self.wall_src = src
        self.wall_scaled = None
        if animate and previous is not None and self.shell.settings.get("animations") != "off":
            self.old_scaled = previous
            self.fade = 0.0
            if self._fade_anim:
                self._fade_anim.cancel()

            def step(t):
                self.fade = t
                self.area.queue_draw()

            def done():
                self.old_scaled = None
                self.area.queue_draw()
            self._fade_anim = ui.Anim(self.area, 450, step, done, ease=ui.ease_in_out)
        else:
            self.old_scaled = None
            self.fade = 1.0
            self.area.queue_draw()

    def _scaled(self, w, h):
        if self.wall_src is None:
            return None
        if self.wall_scaled and self.wall_scaled[0] == w and self.wall_scaled[1] == h:
            return self.wall_scaled
        sw, sh = self.wall_src.get_width(), self.wall_src.get_height()
        scale = max(w / sw, h / sh)
        nw, nh = max(1, int(sw * scale + 0.5)), max(1, int(sh * scale + 0.5))
        pb = self.wall_src.scale_simple(nw, nh, GdkPixbuf.InterpType.BILINEAR)
        self.wall_scaled = (w, h, pb, (w - nw) // 2, (h - nh) // 2)
        return self.wall_scaled

    def on_draw(self, widget, cr):
        a = widget.get_allocation()
        p = palette.build(self.shell.settings.get("mode", "light"), self.shell.settings.get("accent", "teal"))
        r, g, b = palette.hex_to_rgb(p["bg_alt"])
        cr.set_source_rgb(r / 255, g / 255, b / 255)
        cr.paint()
        if self.old_scaled is not None:
            _w, _h, pb, x, y = self.old_scaled
            Gdk.cairo_set_source_pixbuf(cr, pb, x, y)
            cr.paint()
        cur = self._scaled(a.width, a.height)
        if cur is not None:
            _w, _h, pb, x, y = cur
            Gdk.cairo_set_source_pixbuf(cr, pb, x, y)
            cr.paint_with_alpha(self.fade)
        return False

    # ------------------------------------------------------------ icons
    def queue_refresh(self):
        if not self._refresh_id:
            self._refresh_id = GLib.timeout_add(250, self._do_refresh)

    def _do_refresh(self):
        self._refresh_id = 0
        self.refresh()
        return False

    def refresh(self):
        folder = Gio.File.new_for_path(self.dir)
        folder.enumerate_children_async(ATTRS, Gio.FileQueryInfoFlags.NONE, GLib.PRIORITY_LOW, None,
                                        self._enumerated, folder)

    def _enumerated(self, folder, res, _data):
        try:
            enum = folder.enumerate_children_finish(res)
        except GLib.Error:
            return
        infos = []
        while True:
            info = enum.next_file(None)
            if info is None:
                break
            if info.get_is_hidden() or info.get_is_backup():
                continue
            infos.append(info)
        enum.close(None)
        infos.sort(key=lambda i: (i.get_file_type() != Gio.FileType.DIRECTORY, i.get_display_name().lower()))
        for c in self.grid.get_children():
            self.grid.remove(c)
            c.destroy()
        for info in infos:
            self.grid.add(self._make_item(folder.get_child(info.get_name()), info))
        self.grid.show_all()

    def _make_item(self, gfile, info):
        child = Gtk.FlowBoxChild()
        child.set_direction(Gtk.TextDirection.LTR)
        child.gfile = gfile
        child.app = None
        name = info.get_display_name()
        icon = info.get_icon()
        image = None
        if name.endswith(".desktop"):
            try:
                child.app = Gio.DesktopAppInfo.new_from_filename(gfile.get_path())
            except TypeError:
                child.app = None
            if child.app is not None:
                name = apps.display_name(child.app)
                if apps.known_for(child.app.get_id()):
                    image = apps.make_tile(child.app, ICON)
                else:
                    icon = child.app.get_icon() or icon
        thumb = info.get_attribute_byte_string("thumbnail::path")
        if image is None and thumb:
            try:
                pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(thumb, ICON, ICON, True)
                image = Gtk.Image.new_from_pixbuf(pb)
            except GLib.Error:
                image = None
        if image is None:
            image = Gtk.Image.new_from_gicon(icon or Gio.ThemedIcon.new("text-x-generic"), Gtk.IconSize.DIALOG)
            image.set_pixel_size(ICON)
        image.set_halign(Gtk.Align.CENTER)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.set_direction(Gtk.TextDirection.LTR)
        box.pack_start(image, False, False, 0)
        lbl = Gtk.Label(label=name)
        lbl.set_justify(Gtk.Justification.CENTER)
        lbl.set_line_wrap(True)
        lbl.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        lbl.set_lines(2)
        lbl.set_ellipsize(Pango.EllipsizeMode.END)
        lbl.set_max_width_chars(12)
        lbl.set_halign(Gtk.Align.CENTER)
        ui.css_class(lbl, "desk-label")
        box.pack_start(lbl, False, False, 0)
        box.set_size_request(92, -1)

        ev = Gtk.EventBox()
        ev.set_visible_window(False)
        ev.add(box)
        ev.connect("button-press-event", lambda _w, e: self.on_item_press(child, e))
        child.add(ev)
        return child

    def on_activate(self, _grid, child):
        if child.app is not None:
            apps.launch(child.app)
        else:
            apps.open_uri(child.gfile.get_uri())

    def on_key(self, _w, event):
        if event.keyval in (Gdk.KEY_Delete, Gdk.KEY_KP_Delete):
            for c in self.grid.get_selected_children():
                self._trash(c)
            return True
        return False

    # ------------------------------------------------------------ menus
    def _menu(self, entries, event, widget):
        menu = Gtk.Menu()
        for e in entries:
            if e is None:
                menu.append(Gtk.SeparatorMenuItem())
                continue
            mi = Gtk.MenuItem(label=e[0])
            mi.connect("activate", lambda _m, cb=e[1]: cb())
            menu.append(mi)
        menu.show_all()
        menu.attach_to_widget(widget, None)
        menu.popup_at_pointer(event)

    def on_background_press(self, widget, event):
        if event.type != Gdk.EventType.BUTTON_PRESS:
            return False
        self.grid.unselect_all()
        if event.button == 3:
            self._menu([
                ("New Folder", self.new_folder),
                ("Open Terminal Here", lambda: apps.spawn(["x-terminal-emulator", "--working-directory", self.dir])),
                ("Open Desktop in Files", lambda: apps.open_uri(Gio.File.new_for_path(self.dir).get_uri())),
                None,
                ("Change Wallpaper…", lambda: apps.spawn(["lumen-settings", "--page", "personalise"])),
                ("Display Settings…", lambda: apps.spawn(["lumen-settings", "--page", "display"])),
            ], event, widget)
            return True
        return False

    def on_item_press(self, child, event):
        if event.type != Gdk.EventType.BUTTON_PRESS or event.button != 3:
            return False
        if not child.is_selected():
            self.grid.unselect_all()
            self.grid.select_child(child)
        self._menu([
            ("Open", lambda: self.on_activate(self.grid, child)),
            None,
            ("Rename…", lambda: self.rename(child)),
            ("Move to Trash", lambda: [self._trash(c) for c in self.grid.get_selected_children()]),
        ], event, child)
        return True

    def _trash(self, child):
        try:
            child.gfile.trash(None)
        except GLib.Error as e:
            apps.notify("Couldn't move to Trash", e.message)

    def new_folder(self):
        base = os.path.join(self.dir, "New Folder")
        path, n = base, 2
        while os.path.exists(path):
            path = "%s %d" % (base, n)
            n += 1
        try:
            os.mkdir(path)
        except OSError as e:
            apps.notify("Couldn't create folder", str(e))

    def rename(self, child):
        dlg = Gtk.Dialog(title="Rename", modal=True)
        dlg.set_keep_above(True)
        dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
        ok = dlg.add_button("Rename", Gtk.ResponseType.OK)
        ok.get_style_context().add_class("suggested-action")
        dlg.set_default_response(Gtk.ResponseType.OK)
        entry = Gtk.Entry()
        entry.set_text(child.gfile.get_basename())
        entry.set_activates_default(True)
        entry.set_width_chars(32)
        area = dlg.get_content_area()
        area.set_spacing(8)
        area.set_border_width(14)
        area.pack_start(ui.label("New name"), False, False, 0)
        area.pack_start(entry, False, False, 0)
        dlg.show_all()
        base = child.gfile.get_basename()
        dot = base.rfind(".")
        entry.select_region(0, dot if dot > 0 else -1)
        if dlg.run() == Gtk.ResponseType.OK:
            new = entry.get_text().strip()
            if new and new != base and "/" not in new:
                try:
                    child.gfile.set_display_name(new, None)
                except GLib.Error as e:
                    apps.notify("Couldn't rename", e.message)
        dlg.destroy()
