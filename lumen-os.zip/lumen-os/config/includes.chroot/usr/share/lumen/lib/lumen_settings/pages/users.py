"""Users: multiple accounts, passwords, admin rights, guest account, account picture."""
import grp
import os
import pwd
import re
import shutil

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GdkPixbuf, GLib, Gtk  # noqa: E402

from lumen import ui  # noqa: E402
from ..widgets import (Page, FormDialog, avatar, button, confirm, message, password_entry,  # noqa: E402
                       password_strength, set_subtitle)

ADMIN_HELPER = "/usr/libexec/lumen/lumen-users-admin"
SELF_HELPER = "/usr/libexec/lumen/lumen-passwd-self"
GUEST = "guest"
NO_LOGIN = ("nologin", "false")
USERNAME_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")


def list_users():
    try:
        admins = set(grp.getgrnam("sudo").gr_mem)
        sudo_gid = grp.getgrnam("sudo").gr_gid
    except KeyError:
        admins, sudo_gid = set(), -1
    users = []
    for p in pwd.getpwall():
        if p.pw_uid < 1000 or p.pw_uid >= 60000:
            continue
        if os.path.basename(p.pw_shell) in NO_LOGIN:
            continue
        users.append({
            "name": p.pw_name,
            "full": p.pw_gecos.split(",")[0].strip() or p.pw_name,
            "uid": p.pw_uid,
            "admin": p.pw_name in admins or p.pw_gid == sudo_gid,
            "guest": p.pw_name == GUEST,
            "home": p.pw_dir,
        })
    users.sort(key=lambda u: (u["guest"], u["uid"] != os.getuid(), not u["admin"], u["full"].lower()))
    return users


def explain_failure(err):
    err = (err or "").strip()
    if "dismissed" in err.lower() or "Not authorized" in err or "Request dismissed" in err:
        return "You need to enter an administrator's password to do this."
    return err.splitlines()[-1] if err else "Something went wrong."


class UsersPage(Page):
    title = "Users"

    def __init__(self, app):
        super().__init__(app)
        self.me = pwd.getpwuid(os.getuid()).pw_name

        add = button("+ Add user", self.add_user, "suggested-action")
        self.header_end.pack_end(add, False, False, 0)

        self.section("Accounts")
        self.accounts = self.card()

        self.section("Guest")
        self.guest_card = self.card()
        self.guest_switch = Gtk.Switch()
        self.guest_switch.connect("state-set", self.on_guest_switch)
        self.guest_card.row("Guest account",
                            "Lets anyone use this computer without a password. "
                            "Their files are deleted when they sign out.",
                            self.guest_switch)

        self.section("This account")
        self.me_card = self.card()
        self.me_card.row("Account picture", "Shown in Settings and on the login screen.",
                         button("Change…", self.change_picture))
        self.me_card.row("Colours, mode and wallpaper", "Personalise how Lumen looks for you.",
                         button("Personalise…", lambda: self.window.show_page("personalise")))
        self._busy = False
        self.refresh()

    def on_shown(self):
        self.refresh()

    # ------------------------------------------------------------ list
    def refresh(self):
        self.accounts.clear()
        users = list_users()
        self.users = users
        admins = [u for u in users if u["admin"]]
        is_admin = any(u["admin"] and u["name"] == self.me for u in users)
        for u in users:
            if u["guest"]:
                continue
            bits = ["Administrator" if u["admin"] else "Standard user"]
            if u["name"] == self.me:
                bits.append("signed in")
            sub = " · ".join(bits) + "   ·   " + u["name"]
            actions = Gtk.Box(spacing=6)
            pw_label = "Change password"
            actions.pack_start(button(pw_label, lambda u=u: self.change_password(u)), False, False, 0)
            if is_admin:
                more = Gtk.MenuButton()
                more.set_relief(Gtk.ReliefStyle.NONE)
                img = Gtk.Image.new_from_icon_name("view-more-symbolic", Gtk.IconSize.BUTTON)
                if more.get_child() is not None:
                    more.remove(more.get_child())
                more.add(img)
                more.set_tooltip_text("More")
                menu = Gtk.Menu()
                self._menu_item(menu, "Rename…", lambda u=u: self.rename(u))
                if u["admin"]:
                    self._menu_item(menu, "Make standard user", lambda u=u: self.set_admin(u, False),
                                    sensitive=len(admins) > 1 and u["name"] != self.me)
                else:
                    self._menu_item(menu, "Make administrator", lambda u=u: self.set_admin(u, True))
                menu.append(Gtk.SeparatorMenuItem())
                self._menu_item(menu, "Delete account…", lambda u=u: self.delete(u),
                                sensitive=u["name"] != self.me and not (u["admin"] and len(admins) == 1))
                menu.show_all()
                more.set_popup(menu)
                actions.pack_start(more, False, False, 0)
            pic = self._picture(u)
            self.accounts.row(u["full"], sub, actions, prefix=pic)
        guest = next((u for u in users if u["guest"]), None)
        self._busy = True
        self.guest_switch.set_active(guest is not None)
        self.guest_switch.set_sensitive(is_admin or guest is None)
        self._busy = False
        if guest is not None:
            set_subtitle(self.guest_card.get_children()[0],
                         "On. No password · files cleared on sign-out.")
        else:
            set_subtitle(self.guest_card.get_children()[0],
                         "Lets anyone use this computer without a password. "
                         "Their files are deleted when they sign out.")

    def _picture(self, u):
        face = os.path.join(u["home"], ".face")
        try:
            if os.access(face, os.R_OK):
                pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(face, 40, 40, True)
                img = Gtk.Image.new_from_pixbuf(pb)
                return img
        except GLib.Error:
            pass
        return avatar(u["full"], u["name"])

    def _menu_item(self, menu, text, cb, sensitive=True):
        mi = Gtk.MenuItem(label=text)
        mi.set_sensitive(sensitive)
        mi.connect("activate", lambda *_a: cb())
        menu.append(mi)

    # ------------------------------------------------------------ helpers
    def run_admin(self, args, stdin=None, done_msg=None):
        def done(ok, _out, err):
            if not ok:
                message(self.window, "Couldn't make that change", explain_failure(err), Gtk.MessageType.ERROR)
            elif done_msg:
                ui.run_async(["notify-send", "-i", "system-users", done_msg])
            self.refresh()
        ui.run_async(["pkexec", ADMIN_HELPER] + args, done, stdin_text=stdin)

    # ------------------------------------------------------------ actions
    def change_password(self, u):
        mine = u["name"] == self.me
        dlg = FormDialog(self.window, "Change password", "Change password")
        dlg.note(("Choose a new password for your account. You'll be asked for your current password next."
                  if mine else
                  "Set a new password for %s. You'll be asked for an administrator password." % u["full"]))
        new = dlg.field("New password", password_entry())
        again = dlg.field("Confirm", password_entry())

        def check(*_a):
            a, b = new.get_text(), again.get_text()
            hint = password_strength(a)
            if b and a != b:
                hint = "The passwords don't match."
            dlg.hint.set_text(hint)
            dlg.ok.set_sensitive(len(a) >= 6 and a == b)
        new.connect("changed", check)
        again.connect("changed", check)
        check()
        dlg.show_all()
        res = dlg.run()
        pw = new.get_text()
        dlg.destroy()
        if res != Gtk.ResponseType.OK:
            return
        if mine:
            def done(ok, _out, err):
                if ok:
                    message(self.window, "Password changed", "Use your new password next time you sign in.")
                else:
                    message(self.window, "Password not changed", explain_failure(err), Gtk.MessageType.ERROR)
            ui.run_async(["pkexec", SELF_HELPER], done, stdin_text=pw + "\n")
        else:
            self.run_admin(["set-password", u["name"]], pw + "\n", "Password changed for %s" % u["full"])

    def add_user(self):
        dlg = FormDialog(self.window, "Add user", "Add user")
        full = dlg.field("Full name", Gtk.Entry())
        username = dlg.field("Username", Gtk.Entry())
        kind = Gtk.ComboBoxText()
        kind.append("standard", "Standard user")
        kind.append("admin", "Administrator")
        kind.set_active_id("standard")
        dlg.field("Account type", kind)
        new = dlg.field("Password", password_entry())
        again = dlg.field("Confirm", password_entry())
        dlg.note("Administrators can install software and change settings for everyone.")
        state = {"auto": True}
        taken = {u["name"] for u in self.users} | {p.pw_name for p in pwd.getpwall()}

        def suggest(*_a):
            if state["auto"]:
                base = re.sub(r"[^a-z0-9]", "", full.get_text().strip().split(" ")[0].lower()) if full.get_text().strip() else ""
                if base and base[0].isdigit():
                    base = "u" + base
                username.handler_block_by_func(on_user)
                username.set_text(base[:32])
                username.handler_unblock_by_func(on_user)
            check()

        def on_user(*_a):
            state["auto"] = False
            check()

        def check(*_a):
            name = username.get_text()
            a, b = new.get_text(), again.get_text()
            problem = ""
            if name and not USERNAME_RE.match(name):
                problem = "Usernames use lowercase letters, numbers, - and _, and start with a letter."
            elif name in taken:
                problem = "That username is already taken."
            elif b and a != b:
                problem = "The passwords don't match."
            dlg.hint.set_text(problem or password_strength(a))
            dlg.ok.set_sensitive(bool(full.get_text().strip()) and bool(USERNAME_RE.match(name or ""))
                                 and name not in taken and len(a) >= 6 and a == b)
        full.connect("changed", suggest)
        username.connect("changed", on_user)
        new.connect("changed", check)
        again.connect("changed", check)
        check()
        dlg.show_all()
        res = dlg.run()
        values = (full.get_text().strip(), username.get_text(), kind.get_active_id() == "admin", new.get_text())
        dlg.destroy()
        if res != Gtk.ResponseType.OK:
            return
        fullname, name, admin, pw = values
        args = ["add-user", name, "--fullname", fullname] + (["--admin"] if admin else [])
        self.run_admin(args, pw + "\n", "Added %s" % fullname)

    def rename(self, u):
        dlg = FormDialog(self.window, "Rename", "Rename")
        entry = dlg.field("Full name", Gtk.Entry())
        entry.set_text(u["full"])
        dlg.note("This changes the name people see. The username (%s) stays the same." % u["name"])
        dlg.show_all()
        res = dlg.run()
        new = entry.get_text().strip()
        dlg.destroy()
        if res == Gtk.ResponseType.OK and new and new != u["full"]:
            self.run_admin(["set-fullname", u["name"], new])

    def set_admin(self, u, admin):
        self.run_admin(["set-admin", u["name"], "yes" if admin else "no"])

    def delete(self, u):
        if not confirm(self.window, "Delete %s's account?" % u["full"],
                       "Their files in %s will be deleted too. This can't be undone." % u["home"],
                       "Delete account", destructive=True):
            return
        self.run_admin(["delete-user", u["name"]], None, "Deleted %s" % u["full"])

    def on_guest_switch(self, _sw, state):
        if self._busy:
            return False
        self.run_admin(["guest", "enable" if state else "disable"])
        return False

    def change_picture(self):
        dlg = Gtk.FileChooserDialog(title="Choose a picture", transient_for=self.window,
                                    action=Gtk.FileChooserAction.OPEN)
        dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
        ok = dlg.add_button("Use picture", Gtk.ResponseType.OK)
        ui.css_class(ok, "suggested-action")
        flt = Gtk.FileFilter()
        flt.set_name("Pictures")
        flt.add_mime_type("image/*")
        dlg.add_filter(flt)
        pictures = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_PICTURES)
        if pictures:
            dlg.set_current_folder(pictures)
        res = dlg.run()
        path = dlg.get_filename()
        dlg.destroy()
        if res != Gtk.ResponseType.OK or not path:
            return
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(path)
            side = min(pb.get_width(), pb.get_height())
            pb = pb.new_subpixbuf((pb.get_width() - side) // 2, (pb.get_height() - side) // 2, side, side)
            pb = pb.scale_simple(256, 256, GdkPixbuf.InterpType.HYPER)
            face = os.path.expanduser("~/.face")
            pb.savev(face + ".tmp", "png", [], [])
            shutil.move(face + ".tmp", face)
            os.chmod(face, 0o644)
            # Let the login screen read it (home folders are private by default).
            home = os.path.expanduser("~")
            mode = os.stat(home).st_mode
            if not mode & 0o001:
                os.chmod(home, mode | 0o001)
        except (GLib.Error, OSError) as e:
            message(self.window, "Couldn't use that picture", str(e), Gtk.MessageType.ERROR)
        self.refresh()
