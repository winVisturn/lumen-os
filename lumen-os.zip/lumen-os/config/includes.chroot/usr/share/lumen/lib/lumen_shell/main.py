"""Lumen Shell - entry point.

    lumen-shell              start the shell (bar, dock, desktop, launcher)
    lumen-shell --launcher   show/hide the app launcher in the running shell
    lumen-shell --power      show the shut down dialog
"""
import signal
import sys

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Wnck", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk, Wnck  # noqa: E402

from lumen import apps, config, ui  # noqa: E402


class Shell(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.lumen.Shell",
                         flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.add_main_option("launcher", 0, GLib.OptionFlags.NONE, GLib.OptionArg.NONE,
                             "Show or hide the app launcher", None)
        self.add_main_option("power", 0, GLib.OptionFlags.NONE, GLib.OptionArg.NONE,
                             "Show the shut down dialog", None)
        self.add_main_option("quit", 0, GLib.OptionFlags.NONE, GLib.OptionArg.NONE,
                             "Stop the running shell", None)
        self.started = False

    def do_command_line(self, cmd):
        opts = cmd.get_options_dict().end().unpack()
        if opts.get("quit"):
            if self.started:
                self.quit()
            return 0
        if not self.started:
            if opts.get("launcher") or opts.get("power"):
                # Only a remote command: don't start a second shell.
                if not cmd.get_is_remote():
                    print("Lumen Shell is not running.", file=sys.stderr)
                    return 1
            self.start()
        if opts.get("launcher"):
            self.launcher.toggle()
        if opts.get("power"):
            self.power.ask("shutdown")
        return 0

    def start(self):
        from .bar import TopBar
        from .desktop import Desktop
        from .dock import Dock
        from .launcher import Launcher
        from .power import Power

        self.started = True
        self.hold()
        self.settings = config.load()
        Wnck.set_client_type(Wnck.ClientType.PAGER)
        self.wnck = Wnck.Screen.get_default()
        self.wnck.force_update()
        self.index = apps.AppIndex()
        self.power = Power(self)

        self.desktop = Desktop(self)
        self.add_window(self.desktop)
        self.desktop.place()
        self.desktop.show_all()

        self.bar = TopBar(self)
        self.add_window(self.bar)
        self.bar.show()

        self.dock = Dock(self)
        self.add_window(self.dock)
        self.dock.show_all()

        self.launcher = Launcher(self)
        self.add_window(self.launcher)

        self._watch = ui.settings_watcher(self.on_settings_changed)
        screen = Gdk.Screen.get_default()
        screen.connect("size-changed", self.on_screen_changed)
        screen.connect("monitors-changed", self.on_screen_changed)
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGTERM, self._on_term)
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGINT, self._on_term)

    def _on_term(self):
        self.quit()
        return False

    def on_settings_changed(self):
        old = self.settings
        self.settings = config.load()
        self.bar.reload()
        if any(old.get(k) != self.settings.get(k) for k in ("dock_apps", "dock_icon_size")):
            self.dock.reload()
        self.desktop.reload()

    def on_screen_changed(self, *_a):
        # e.g. a VM window was resized, or a monitor was plugged in.
        GLib.timeout_add(200, self._replace)

    def _replace(self):
        self.desktop.place()
        self.bar.place()
        self.dock.place()
        return False


def main():
    GLib.set_prgname("lumen-shell")
    GLib.set_application_name("Lumen Shell")
    app = Shell()
    return app.run(sys.argv)
