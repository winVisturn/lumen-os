"""Wi-Fi & Network (uses NetworkManager's nmcli)."""
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk  # noqa: E402

from lumen import apps, ui  # noqa: E402
from ..widgets import Page, FormDialog, button, message, password_entry, set_subtitle  # noqa: E402


def split_terse(line):
    """nmcli -t escapes ':' as '\\:' inside fields."""
    out, cur, esc = [], [], False
    for ch in line:
        if esc:
            cur.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            out.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    out.append("".join(cur))
    return out


def signal_icon(strength):
    level = "excellent" if strength >= 75 else "good" if strength >= 50 else "ok" if strength >= 25 else "weak"
    return "network-wireless-signal-%s-symbolic" % level


class NetworkPage(Page):
    title = "Wi-Fi & Network"

    def __init__(self, app):
        super().__init__(app)
        self.refresh_btn = button("Refresh", self.scan)
        self.header_end.pack_end(self.refresh_btn, False, False, 0)
        self.spinner = Gtk.Spinner()
        self.header_end.pack_end(self.spinner, False, False, 0)

        self.section("Wi-Fi")
        top = self.card()
        self.wifi_switch = Gtk.Switch()
        self.wifi_switch.connect("state-set", self.on_wifi_toggle)
        self.wifi_row = top.row("Wi-Fi", "", self.wifi_switch)
        self.networks = self.card()

        self.section("Wired")
        self.wired = self.card()

        self.section("More")
        more = self.card()
        more.row("Advanced network settings", "VPN, proxies, static IP addresses and hidden networks.",
                 button("Open…", lambda: apps.spawn(["nm-connection-editor"])))
        self._updating = False
        self.wifi_device = None
        self.saved = set()
        self._timer = 0

    def on_shown(self):
        self.load()
        if not self._timer:
            self._timer = GLib.timeout_add_seconds(15, self._tick)

    def _tick(self):
        if not self.get_mapped():
            self._timer = 0
            return False
        self.load(rescan=False)
        return True

    # ------------------------------------------------------------ loading
    def load(self, rescan=True):
        ui.run_async(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device"], self._got_devices)
        ui.run_async(["nmcli", "radio", "wifi"], self._got_radio)
        ui.run_async(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"], self._got_saved)
        self.scan(rescan)

    def scan(self, rescan=True):
        self.spinner.start()
        ui.run_async(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi", "list",
                      "--rescan", "yes" if rescan else "no"], self._got_networks)

    def _got_devices(self, ok, out, err):
        self.wired.clear()
        if not ok:
            self.wired.row("Network service isn't running", err.strip() or None)
            return
        self.wifi_device = None
        any_wired = False
        for line in out.splitlines():
            dev, kind, state, conn = (split_terse(line) + ["", "", "", ""])[:4]
            if kind == "wifi":
                self.wifi_device = dev
            elif kind == "ethernet":
                any_wired = True
                connected = state.startswith("connected")
                self.wired.row("Ethernet (%s)" % dev,
                               "Connected · %s" % conn if connected else "Cable unplugged" if "unavailable" in state
                               else "Not connected")
        if not any_wired:
            self.wired.row("No wired network adapter", None)

    def _got_radio(self, ok, out, _err):
        self._updating = True
        self.wifi_switch.set_active(out.strip() == "enabled")
        self._updating = False

    def _got_saved(self, ok, out, _err):
        self.saved = {split_terse(l)[0] for l in out.splitlines() if "wireless" in l}

    def _got_networks(self, ok, out, err):
        self.spinner.stop()
        self.networks.clear()
        if not self.wifi_switch.get_active():
            set_subtitle(self.wifi_row, "Off")
            self.networks.set_visible(False)
            return
        self.networks.set_visible(True)
        seen = {}
        for line in out.splitlines():
            parts = split_terse(line)
            if len(parts) < 4:
                continue
            in_use, ssid, sig, sec = parts[0] == "*", parts[1], parts[2], parts[3]
            if not ssid:
                continue
            try:
                strength = int(sig)
            except ValueError:
                strength = 0
            prev = seen.get(ssid)
            if prev is None or in_use or (strength > prev[1] and not prev[0]):
                seen[ssid] = (in_use, strength, sec)
        if not seen:
            set_subtitle(self.wifi_row, "No networks found" if ok else (err.strip() or "No Wi-Fi adapter"))
            return
        current = [s for s, v in seen.items() if v[0]]
        set_subtitle(self.wifi_row, "Connected to %s" % current[0] if current else "Not connected")
        for ssid, (in_use, strength, sec) in sorted(seen.items(), key=lambda kv: (not kv[1][0], -kv[1][1])):
            secured = sec not in ("", "--")
            icon = Gtk.Box(spacing=4)
            img = Gtk.Image.new_from_icon_name(signal_icon(strength), Gtk.IconSize.MENU)
            icon.pack_start(img, False, False, 0)
            sub = "Connected" if in_use else ("Saved · " if ssid in self.saved else "") + \
                ("Secured" if secured else "Open network")
            end = Gtk.Box(spacing=6)
            if secured:
                end.pack_start(Gtk.Image.new_from_icon_name("changes-prevent-symbolic", Gtk.IconSize.MENU),
                               False, False, 0)
            if in_use:
                end.pack_start(button("Disconnect", self.disconnect), False, False, 0)
            if ssid in self.saved:
                end.pack_start(button("Forget", lambda s=ssid: self.forget(s)), False, False, 0)
            self.networks.row(ssid, sub, end, prefix=icon,
                              activate=None if in_use else (lambda s=ssid, sc=secured: self.connect_to(s, sc)))

    # ------------------------------------------------------------ actions
    def on_wifi_toggle(self, _sw, state):
        if self._updating:
            return False
        ui.run_async(["nmcli", "radio", "wifi", "on" if state else "off"],
                     lambda *_a: GLib.timeout_add(1500, lambda: (self.load(), False)[1]))
        return False

    def connect_to(self, ssid, secured):
        if ssid in self.saved:
            self._run_connect(["nmcli", "connection", "up", "id", ssid], ssid)
            return
        argv = ["nmcli", "device", "wifi", "connect", ssid]
        if secured:
            dlg = FormDialog(self.window, "Connect to %s" % ssid, "Connect")
            pw = dlg.field("Password", password_entry())
            show = Gtk.CheckButton(label="Show password")
            show.connect("toggled", lambda b: pw.set_visibility(b.get_active()))
            dlg.field("", show)
            pw.connect("changed", lambda e: dlg.ok.set_sensitive(len(e.get_text()) >= 8))
            dlg.ok.set_sensitive(False)
            dlg.show_all()
            res = dlg.run()
            password = pw.get_text()
            dlg.destroy()
            if res != Gtk.ResponseType.OK:
                return
            argv += ["password", password]
        if self.wifi_device:
            argv += ["ifname", self.wifi_device]
        self._run_connect(argv, ssid)

    def _run_connect(self, argv, ssid):
        self.spinner.start()
        set_subtitle(self.wifi_row, "Connecting to %s…" % ssid)

        def done(ok, out, err):
            self.spinner.stop()
            if not ok:
                msg = (err or out).strip().splitlines()
                message(self.window, "Couldn't connect to %s" % ssid,
                        "Check the password and try again." if any("secrets" in m.lower() or "password" in m.lower()
                                                                  for m in msg) else (msg[-1] if msg else ""),
                        Gtk.MessageType.ERROR)
            self.load(rescan=False)
        ui.run_async(argv, done)

    def disconnect(self):
        if self.wifi_device:
            ui.run_async(["nmcli", "device", "disconnect", self.wifi_device], lambda *_a: self.load(rescan=False))

    def forget(self, ssid):
        ui.run_async(["nmcli", "connection", "delete", "id", ssid], lambda *_a: self.load(rescan=False))
