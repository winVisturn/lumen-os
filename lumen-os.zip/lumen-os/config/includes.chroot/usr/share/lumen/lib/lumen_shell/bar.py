"""The top bar: Lumen menu, active app name, clock, network, sound, battery, power."""
import glob
import os
import pwd
import re
import time

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Wnck", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk, Wnck  # noqa: E402

from lumen import apps, ui  # noqa: E402

HEIGHT = 30


def _icon(name, fallback="image-missing"):
    theme = Gtk.IconTheme.get_default()
    if not theme.has_icon(name):
        name = fallback
    img = Gtk.Image.new_from_icon_name(name, Gtk.IconSize.MENU)
    img.set_pixel_size(16)
    return img


def _set_icon(img, name, fallback):
    theme = Gtk.IconTheme.get_default()
    img.set_from_icon_name(name if theme.has_icon(name) else fallback, Gtk.IconSize.MENU)
    img.set_pixel_size(16)


class MenuPopover(Gtk.Popover):
    """A popover holding a simple list of menu entries."""

    def __init__(self, relative_to):
        super().__init__()
        self.set_relative_to(relative_to)
        self.set_position(Gtk.PositionType.BOTTOM)
        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        ui.css_class(self.box, "bar-pop")
        self.add(self.box)

    def add_header(self, title, sub=None):
        self.box.pack_start(ui.label(title, "bar-pop-title"), False, False, 0)
        if sub:
            self.box.pack_start(ui.label(sub, "bar-pop-sub"), False, False, 0)
        return self

    def add_item(self, text, callback):
        b = Gtk.ModelButton(text=text)

        def clicked(_b):
            self.popdown()
            GLib.timeout_add(120, lambda: (callback(), False)[1])
        b.connect("clicked", clicked)
        self.box.pack_start(b, False, False, 0)
        return b

    def add_widget(self, widget):
        self.box.pack_start(widget, False, False, 0)
        return widget

    def add_separator(self):
        sep = Gtk.Separator()
        sep.set_margin_top(4)
        sep.set_margin_bottom(4)
        self.box.pack_start(sep, False, False, 0)


def bar_button(child):
    b = Gtk.MenuButton()
    b.set_relief(Gtk.ReliefStyle.NONE)
    b.set_focus_on_click(False)
    if b.get_child():
        b.remove(b.get_child())
    b.add(child)
    return b


class TopBar(Gtk.Window):
    def __init__(self, shell):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.shell = shell
        self.set_title("lumen-bar")
        self.set_decorated(False)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_accept_focus(False)
        self.stick()

        self.root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        ui.css_class(self.root, "lumen-bar")
        self.root.set_size_request(-1, HEIGHT)
        self.add(self.root)
        ui.setup_transparency(self, self.root)

        # ---- left: Lumen menu + app name
        left = Gtk.Box(spacing=2)
        left.set_margin_start(8)
        logo = Gtk.Image.new_from_icon_name("lumen-logo", Gtk.IconSize.MENU)
        logo.set_pixel_size(18)
        self.logo_btn = bar_button(logo)
        ui.css_class(self.logo_btn, "logo-button")
        self.logo_btn.set_tooltip_text("Lumen menu")
        self.logo_btn.set_popover(self._lumen_menu(self.logo_btn))
        left.pack_start(self.logo_btn, False, False, 0)
        self.app_label = ui.label("Desktop", "app-name")
        self.app_label.set_margin_start(6)
        left.pack_start(self.app_label, False, False, 0)
        self.root.pack_start(left, False, False, 0)

        # ---- centre: clock + calendar
        self.clock_label = ui.label("", "clock", xalign=0.5)
        self.clock_btn = bar_button(self.clock_label)
        self.clock_btn.set_popover(self._calendar_popover(self.clock_btn))
        self.root.set_center_widget(self.clock_btn)

        # ---- right: status
        right = Gtk.Box(spacing=0)
        right.set_margin_end(8)
        self.net_img = _icon("network-wireless-signal-excellent-symbolic", "network-wired-symbolic")
        self.net_btn = bar_button(self.net_img)
        self.net_btn.set_popover(self._net_popover(self.net_btn))
        right.pack_start(self.net_btn, False, False, 0)

        self.vol_img = _icon("audio-volume-high-symbolic", "audio-speakers-symbolic")
        self.vol_btn = bar_button(self.vol_img)
        self.vol_btn.set_popover(self._volume_popover(self.vol_btn))
        self.vol_btn.add_events(Gdk.EventMask.SCROLL_MASK | Gdk.EventMask.SMOOTH_SCROLL_MASK)
        self.vol_btn.connect("scroll-event", self._on_vol_scroll)
        right.pack_start(self.vol_btn, False, False, 0)

        bat_box = Gtk.Box(spacing=5)
        self.bat_img = _icon("battery-level-80-symbolic", "battery-good-symbolic")
        self.bat_label = ui.label("", "battery-label")
        bat_box.pack_start(self.bat_img, False, False, 0)
        bat_box.pack_start(self.bat_label, False, False, 0)
        self.bat_btn = bar_button(bat_box)
        self.bat_pop = MenuPopover(self.bat_btn)
        self.bat_title = ui.label("Battery", "bar-pop-title")
        self.bat_sub = ui.label("", "bar-pop-sub")
        self.bat_pop.add_widget(self.bat_title)
        self.bat_pop.add_widget(self.bat_sub)
        self.bat_pop.box.show_all()
        self.bat_btn.set_popover(self.bat_pop)
        right.pack_start(self.bat_btn, False, False, 0)

        self.power_btn = bar_button(_icon("system-shutdown-symbolic", "application-exit-symbolic"))
        self.power_btn.set_popover(self._power_popover(self.power_btn))
        right.pack_start(self.power_btn, False, False, 0)
        self.root.pack_end(right, False, False, 0)

        for w in (self.bat_btn, self.bat_label, self.vol_btn, self.wifi_switch.get_parent()):
            w.set_no_show_all(True)
        self.root.show_all()
        self.vol_btn.show()
        self.bat_label.show()
        self.battery = self._find_battery()
        self.bat_btn.set_visible(self.battery is not None)

        # ---- state updates
        self._vol_dragging = False
        self._vol_updating = False
        self.update_clock()
        self.update_network()
        GLib.timeout_add_seconds(8, self._net_tick)
        self.update_volume()
        self._start_volume_watch()
        self.update_battery()
        GLib.timeout_add_seconds(30, self._bat_tick)

        screen = shell.wnck
        screen.connect("active-window-changed", lambda *_a: self.update_app_name())
        self.update_app_name()
        self.place()

    # ------------------------------------------------------------ layout
    def place(self):
        g = ui.primary_geometry()
        self.set_size_request(g.width, HEIGHT)
        self.resize(g.width, HEIGHT)
        self.move(g.x, g.y)

    def reload(self):
        self.update_clock()
        self.update_battery()

    # ------------------------------------------------------------ Lumen menu
    def _lumen_menu(self, btn):
        pop = MenuPopover(btn)
        pop.add_item("About Lumen OS", lambda: apps.spawn(["lumen-settings", "--page", "about"]))
        pop.add_item("Settings", lambda: apps.spawn(["lumen-settings"]))
        pop.add_item("Software updates", lambda: apps.spawn(["lumen-settings", "--page", "updates"]))
        pop.add_item("All apps", lambda: self.shell.launcher.show_launcher())
        pop.add_separator()
        pop.add_item("Lock screen", lambda: apps.spawn(["dm-tool", "lock"]))
        pop.add_item("Sleep", lambda: self.shell.power.run("suspend"))
        pop.add_item("Restart…", lambda: self.shell.power.ask("restart"))
        pop.add_item("Shut down…", lambda: self.shell.power.ask("shutdown"))
        pop.add_separator()
        pop.add_item("Log out…", lambda: self.shell.power.ask("logout"))
        pop.box.show_all()
        return pop

    # ------------------------------------------------------------ app name
    def update_app_name(self):
        w = self.shell.wnck.get_active_window()
        name = "Desktop"
        if w is not None and w.get_window_type() not in (Wnck.WindowType.DESKTOP, Wnck.WindowType.DOCK):
            app_id = self.shell.index.id_for_window(w)
            app = self.shell.index.get(app_id) if app_id else None
            if app is not None:
                name = apps.display_name(app)
            else:
                name = (w.get_class_group_name() or w.get_name() or "Desktop").capitalize()
        self.app_label.set_text(name)

    # ------------------------------------------------------------ clock
    def update_clock(self):
        s = self.shell.settings
        fmt = "%H:%M" if s.get("clock_24h", True) else "%-I:%M %p"
        if s.get("clock_show_date", True):
            fmt = "%a %-d %b · " + fmt
        self.clock_label.set_text(time.strftime(fmt))
        if getattr(self, "_clock_id", 0):
            GLib.source_remove(self._clock_id)
        delay = 60 - time.localtime().tm_sec
        self._clock_id = GLib.timeout_add_seconds(max(1, delay), self._clock_tick)

    def _clock_tick(self):
        self._clock_id = 0
        self.update_clock()
        return False

    def _calendar_popover(self, btn):
        pop = Gtk.Popover()
        pop.set_relative_to(btn)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_top(10)
        box.set_margin_bottom(10)
        box.set_margin_start(10)
        box.set_margin_end(10)
        self.cal_title = ui.label("", "bar-pop-title")
        cal = Gtk.Calendar()
        box.pack_start(self.cal_title, False, False, 0)
        box.pack_start(cal, False, False, 0)
        box.show_all()
        pop.add(box)

        def on_show(_p):
            self.cal_title.set_text(time.strftime("%A, %-d %B %Y"))
            now = time.localtime()
            cal.select_month(now.tm_mon - 1, now.tm_year)
            cal.select_day(now.tm_mday)
        pop.connect("show", on_show)
        return pop

    # ------------------------------------------------------------ network
    def _net_popover(self, btn):
        pop = MenuPopover(btn)
        self.net_title = ui.label("Network", "bar-pop-title")
        self.net_sub = ui.label("", "bar-pop-sub")
        pop.add_widget(self.net_title)
        pop.add_widget(self.net_sub)
        row = Gtk.Box(spacing=12)
        row.set_margin_start(8)
        row.set_margin_end(8)
        row.set_margin_top(4)
        row.set_margin_bottom(4)
        row.pack_start(ui.label("Wi-Fi"), True, True, 0)
        self.wifi_switch = Gtk.Switch()
        self.wifi_switch.connect("state-set", self._on_wifi_switch)
        row.pack_end(self.wifi_switch, False, False, 0)
        pop.add_widget(row)
        pop.add_separator()
        pop.add_item("Wi-Fi & Network settings…", lambda: apps.spawn(["lumen-settings", "--page", "network"]))
        pop.box.show_all()
        pop.connect("show", lambda *_a: self.update_network())
        return pop

    def _on_wifi_switch(self, _sw, state):
        if getattr(self, "_net_updating", False):
            return False
        ui.run_async(["nmcli", "radio", "wifi", "on" if state else "off"],
                     lambda *_a: GLib.timeout_add(1500, lambda: (self.update_network(), False)[1]))
        return False

    def _net_tick(self):
        self.update_network()
        return True

    def update_network(self):
        ui.run_async(["nmcli", "-t", "-f", "TYPE,STATE,CONNECTION", "device"], self._got_devices)

    def _got_devices(self, ok, out, _err):
        if not ok:
            _set_icon(self.net_img, "network-offline-symbolic", "network-wired-disconnected-symbolic")
            self.net_title.set_text("Network")
            self.net_sub.set_text("Network service not running")
            return
        wired = wifi = None
        has_wifi = False
        for line in out.splitlines():
            parts = line.split(":")
            if len(parts) < 3:
                continue
            kind, state, conn = parts[0], parts[1], ":".join(parts[2:])
            if kind == "wifi":
                has_wifi = True
                if state == "connected":
                    wifi = conn
            elif kind == "ethernet" and state == "connected":
                wired = conn
        self._has_wifi = has_wifi
        if wired:
            _set_icon(self.net_img, "network-wired-symbolic", "network-transmit-receive-symbolic")
            self.net_title.set_text("Wired")
            self.net_sub.set_text("Connected · %s" % wired)
        elif wifi:
            self.net_title.set_text(wifi)
            self.net_sub.set_text("Connected")
            ui.run_async(["nmcli", "-t", "-f", "ACTIVE,SIGNAL", "device", "wifi", "list", "--rescan", "no"],
                         self._got_signal)
        elif has_wifi:
            _set_icon(self.net_img, "network-wireless-offline-symbolic", "network-wireless-disconnected-symbolic")
            self.net_title.set_text("Wi-Fi")
            self.net_sub.set_text("Not connected")
        else:
            _set_icon(self.net_img, "network-offline-symbolic", "network-wired-disconnected-symbolic")
            self.net_title.set_text("Network")
            self.net_sub.set_text("Not connected")
        ui.run_async(["nmcli", "radio", "wifi"], self._got_radio)

    def _got_signal(self, ok, out, _err):
        strength = 0
        for line in out.splitlines():
            if line.startswith("yes:"):
                try:
                    strength = int(line.split(":")[1])
                except ValueError:
                    pass
        level = "excellent" if strength >= 75 else "good" if strength >= 50 else "ok" if strength >= 25 else "weak"
        _set_icon(self.net_img, "network-wireless-signal-%s-symbolic" % level, "network-wireless-symbolic")

    def _got_radio(self, ok, out, _err):
        self._net_updating = True
        self.wifi_switch.set_active(out.strip() == "enabled")
        self.wifi_switch.get_parent().set_visible(getattr(self, "_has_wifi", False))
        self._net_updating = False

    # ------------------------------------------------------------ volume
    def _volume_popover(self, btn):
        pop = MenuPopover(btn)
        pop.add_header("Sound")
        row = Gtk.Box(spacing=8)
        row.set_margin_start(8)
        row.set_margin_end(8)
        self.mute_btn = Gtk.Button()
        self.mute_btn.set_relief(Gtk.ReliefStyle.NONE)
        self.mute_img = _icon("audio-volume-high-symbolic", "audio-speakers-symbolic")
        self.mute_btn.add(self.mute_img)
        self.mute_btn.connect("clicked", lambda *_a: ui.run_async(
            ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"], lambda *_b: self.update_volume()))
        self.vol_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        self.vol_scale.set_draw_value(False)
        self.vol_scale.set_size_request(200, -1)
        self.vol_scale.connect("value-changed", self._on_vol_changed)
        self.vol_scale.connect("button-press-event", lambda *_a: setattr(self, "_vol_dragging", True) or False)
        self.vol_scale.connect("button-release-event", lambda *_a: setattr(self, "_vol_dragging", False) or False)
        row.pack_start(self.mute_btn, False, False, 0)
        row.pack_start(self.vol_scale, True, True, 0)
        pop.add_widget(row)
        pop.add_separator()
        pop.add_item("Sound settings…", lambda: apps.spawn(["lumen-settings", "--page", "sound"]))
        pop.box.show_all()
        return pop

    def _on_vol_changed(self, scale):
        if self._vol_updating:
            return
        ui.run_async(["pactl", "set-sink-volume", "@DEFAULT_SINK@", "%d%%" % int(scale.get_value())])

    def _on_vol_scroll(self, _w, event):
        step = 0
        if event.direction == Gdk.ScrollDirection.UP:
            step = 5
        elif event.direction == Gdk.ScrollDirection.DOWN:
            step = -5
        elif event.direction == Gdk.ScrollDirection.SMOOTH:
            _ok, _dx, dy = event.get_scroll_deltas()
            step = -5 if dy > 0 else 5 if dy < 0 else 0
        if step:
            target = max(0, min(100, getattr(self, "_volume", 50) + step))
            ui.run_async(["pactl", "set-sink-volume", "@DEFAULT_SINK@", "%d%%" % target],
                         lambda *_a: self.update_volume())
        return True

    def update_volume(self):
        ui.run_async(["pactl", "get-sink-volume", "@DEFAULT_SINK@"], self._got_volume)

    def _got_volume(self, ok, out, _err):
        if not ok:
            self.vol_btn.set_visible(False)
            return
        self.vol_btn.set_visible(True)
        m = re.search(r"(\d+)%", out)
        self._volume = int(m.group(1)) if m else 0
        ui.run_async(["pactl", "get-sink-mute", "@DEFAULT_SINK@"], self._got_mute)

    def _got_mute(self, ok, out, _err):
        muted = "yes" in out.lower()
        v = self._volume
        name = ("audio-volume-muted-symbolic" if muted or v == 0 else
                "audio-volume-low-symbolic" if v < 34 else
                "audio-volume-medium-symbolic" if v < 67 else "audio-volume-high-symbolic")
        _set_icon(self.vol_img, name, "audio-speakers-symbolic")
        _set_icon(self.mute_img, name, "audio-speakers-symbolic")
        self.vol_btn.set_tooltip_text("Muted" if muted else "Volume %d%%" % v)
        if not self._vol_dragging:
            self._vol_updating = True
            self.vol_scale.set_value(min(100, v))
            self._vol_updating = False

    def _start_volume_watch(self):
        """Follow `pactl subscribe` so the icon reacts to volume keys instantly."""
        try:
            proc = Gio.Subprocess.new(["pactl", "subscribe"], Gio.SubprocessFlags.STDOUT_PIPE)
        except GLib.Error:
            GLib.timeout_add_seconds(5, lambda: (self.update_volume(), True)[1])
            return
        self._pactl = proc
        stream = Gio.DataInputStream.new(proc.get_stdout_pipe())
        self._vol_pending = 0

        def schedule():
            if not self._vol_pending:
                self._vol_pending = GLib.timeout_add(80, fire)

        def fire():
            self._vol_pending = 0
            self.update_volume()
            return False

        def got_line(s, res):
            try:
                line, _len = s.read_line_finish_utf8(res)
            except GLib.Error:
                line = None
            if line is None:
                # pactl exited (sound server restarted): try again later
                GLib.timeout_add_seconds(3, lambda: (self._start_volume_watch(), False)[1])
                return
            if "sink" in line or "server" in line:
                schedule()
            s.read_line_async(GLib.PRIORITY_DEFAULT, None, got_line)

        stream.read_line_async(GLib.PRIORITY_DEFAULT, None, got_line)

    # ------------------------------------------------------------ battery
    def _find_battery(self):
        for path in sorted(glob.glob("/sys/class/power_supply/*")):
            try:
                with open(os.path.join(path, "type")) as f:
                    if f.read().strip() == "Battery":
                        if os.path.exists(os.path.join(path, "capacity")):
                            return path
            except OSError:
                continue
        return None

    def _bat_tick(self):
        self.update_battery()
        return True

    def update_battery(self):
        if not self.battery:
            return

        def read(name, default=""):
            try:
                with open(os.path.join(self.battery, name)) as f:
                    return f.read().strip()
            except OSError:
                return default
        try:
            pct = int(read("capacity", "0"))
        except ValueError:
            pct = 0
        status = read("status", "Unknown")
        charging = status in ("Charging", "Full")
        level = min(100, int(round(pct / 10.0)) * 10)
        name = "battery-level-%d%s-symbolic" % (level, "-charging" if charging else "")
        _set_icon(self.bat_img, name, "battery-good-symbolic")
        self.bat_label.set_text("%d%%" % pct)
        self.bat_label.set_visible(bool(self.shell.settings.get("battery_percent", True)))
        self.bat_title.set_text("Battery %d%%" % pct)
        self.bat_sub.set_text({"Charging": "Charging", "Full": "Fully charged",
                               "Discharging": "On battery"}.get(status, status))

    # ------------------------------------------------------------ power
    def _power_popover(self, btn):
        pop = MenuPopover(btn)
        try:
            pw = pwd.getpwuid(os.getuid())
            who = (pw.pw_gecos.split(",")[0] or pw.pw_name)
        except KeyError:
            who = os.environ.get("USER", "")
        pop.add_header(who, "Signed in")
        pop.add_item("Lock screen", lambda: apps.spawn(["dm-tool", "lock"]))
        pop.add_item("Switch user…", lambda: apps.spawn(["dm-tool", "switch-to-greeter"]))
        pop.add_item("Log out…", lambda: self.shell.power.ask("logout"))
        pop.add_separator()
        pop.add_item("Sleep", lambda: self.shell.power.run("suspend"))
        pop.add_item("Restart…", lambda: self.shell.power.ask("restart"))
        pop.add_item("Shut down…", lambda: self.shell.power.ask("shutdown"))
        pop.box.show_all()
        return pop
