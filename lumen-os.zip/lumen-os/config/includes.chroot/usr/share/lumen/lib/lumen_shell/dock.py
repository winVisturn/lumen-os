"""The dock: app launcher button, pinned + running apps, trash."""
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Wnck", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk, Wnck  # noqa: E402

from lumen import apps, config, ui  # noqa: E402

LIFT = 6          # px an icon rises on hover
BOTTOM_GAP = 10   # px between the dock and the bottom of the screen
SHADOW = 18       # px of room around the dock for its shadow


def _app_windows(screen, index, key):
    found = []
    for w in screen.get_windows_stacked() or []:
        if w.is_skip_tasklist() or w.get_window_type() not in (Wnck.WindowType.NORMAL, Wnck.WindowType.DIALOG):
            continue
        if _key_for_window(index, w) == key:
            found.append(w)
    return found


def _key_for_window(index, w):
    app_id = index.id_for_window(w)
    if app_id:
        return app_id
    return "wm:" + (w.get_class_group_name() or w.get_name() or "?").lower()


class DockItem(Gtk.Button):
    def __init__(self, dock, key, kind="app", app=None, wnck_window=None):
        super().__init__()
        self.dock = dock
        self.key = key
        self.kind = kind          # app | launcher | trash
        self.app = app
        self.windows = []
        self.lift = 0.0
        self._anim = None
        self.set_relief(Gtk.ReliefStyle.NONE)
        self.set_focus_on_click(False)
        ui.css_class(self, "dock-item")

        size = dock.icon_size
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        if kind == "launcher":
            self.tile = apps.make_tile(None, size, glyph="view-app-grid-symbolic", tile="utility")
            self.set_tooltip_text("All apps")
        elif kind == "trash":
            self.tile = apps.make_tile(None, size, glyph="user-trash-symbolic", tile="utility")
            self.set_tooltip_text("Trash")
        elif app is not None:
            self.tile = apps.make_tile(app, size)
            self.set_tooltip_text(apps.display_name(app))
        else:
            pb = wnck_window.get_icon() if wnck_window else None
            self.tile = apps.make_tile(None, size, pixbuf=pb)
            self.set_tooltip_text((wnck_window.get_class_group_name() or wnck_window.get_name()) if wnck_window else key)
        self.tile.set_margin_top(LIFT)
        box.pack_start(self.tile, False, False, 0)
        self.dot = Gtk.Box()
        self.dot.set_halign(Gtk.Align.CENTER)
        ui.css_class(self.dot, "dock-dot", "off")
        box.pack_start(self.dot, False, False, 0)
        self.add(box)

        self.add_events(Gdk.EventMask.ENTER_NOTIFY_MASK | Gdk.EventMask.LEAVE_NOTIFY_MASK)
        self.connect("enter-notify-event", lambda *_a: self.animate_lift(1.0))
        self.connect("leave-notify-event", lambda *_a: self.animate_lift(0.0))
        self.connect("clicked", self.on_clicked)
        self.connect("button-press-event", self.on_press)

    # ---------------------------------------------------------- animation
    def _set_lift(self, v):
        self.lift = v
        px = int(round(v * (LIFT - 1)))
        self.tile.set_margin_top(LIFT - px)
        self.tile.set_margin_bottom(px)

    def animate_lift(self, target):
        if self._anim:
            self._anim.cancel()
        start = self.lift
        self._anim = ui.Anim(self, 140, lambda t: self._set_lift(start + (target - start) * t),
                             enabled=self.dock.animated())
        return False

    def bounce(self):
        if not self.dock.animated():
            return
        if self._anim:
            self._anim.cancel()

        def step(t):
            # two hops, the second smaller
            import math
            hop = abs(math.sin(t * math.pi * 2)) * (1.0 if t < 0.5 else 0.5)
            self._set_lift(hop)
        self._anim = ui.Anim(self, 700, step, ease=lambda t: t)

    # ---------------------------------------------------------- state
    def set_running(self, windows):
        self.windows = windows
        ctx = self.dot.get_style_context()
        if windows:
            ctx.remove_class("off")
        else:
            ctx.add_class("off")

    # ---------------------------------------------------------- actions
    def on_clicked(self, _b):
        ts = Gtk.get_current_event_time()
        if self.kind == "launcher":
            self.dock.shell.launcher.toggle()
            return
        if self.kind == "trash":
            apps.open_uri("trash:///")
            return
        if not self.windows:
            if self.app is not None and apps.launch(self.app):
                self.bounce()
            return
        active = self.dock.shell.wnck.get_active_window()
        if active in self.windows and len(self.windows) == 1:
            active.minimize()
            return
        if active in self.windows:
            # cycle through this app's windows
            i = self.windows.index(active)
            target = self.windows[(i - 1) % len(self.windows)]
        else:
            target = self.windows[-1]   # most recently stacked
        if target.is_minimized():
            target.unminimize(ts)
        target.activate(ts)

    def on_press(self, _w, event):
        if event.type != Gdk.EventType.BUTTON_PRESS:
            return False
        if event.button == 3:
            self.show_menu(event)
            return True
        if event.button == 2 and self.app is not None:
            apps.launch(self.app)
            self.bounce()
            return True
        return False

    def show_menu(self, event):
        menu = Gtk.Menu()

        def item(text, cb, sensitive=True):
            mi = Gtk.MenuItem(label=text)
            mi.set_sensitive(sensitive)
            mi.connect("activate", lambda *_a: cb())
            menu.append(mi)

        if self.kind == "trash":
            item("Open Trash", lambda: apps.open_uri("trash:///"))
            item("Empty Trash…", self.dock.empty_trash, self.dock.trash_count > 0)
        elif self.kind == "launcher":
            item("All apps", self.dock.shell.launcher.show_launcher)
            item("Dock settings…", lambda: apps.spawn(["lumen-settings", "--page", "personalise"]))
        else:
            header = Gtk.MenuItem(label=self.get_tooltip_text() or "")
            header.set_sensitive(False)
            menu.append(header)
            menu.append(Gtk.SeparatorMenuItem())
            if self.app is not None:
                item("New window", lambda: apps.launch(self.app))
                if self.key in self.dock.pinned():
                    item("Remove from dock", lambda: self.dock.set_pinned(self.key, False))
                else:
                    item("Keep in dock", lambda: self.dock.set_pinned(self.key, True))
            if self.windows:
                menu.append(Gtk.SeparatorMenuItem())
                n = len(self.windows)
                item("Quit" if n == 1 else "Close %d windows" % n, self.close_all)
        menu.show_all()
        menu.attach_to_widget(self, None)
        menu.popup_at_widget(self, Gdk.Gravity.NORTH, Gdk.Gravity.SOUTH, event)

    def close_all(self):
        ts = Gtk.get_current_event_time()
        for w in list(self.windows):
            w.close(ts)


class Dock(Gtk.Window):
    def __init__(self, shell):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.shell = shell
        self.set_title("lumen-dock")
        self.set_decorated(False)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_accept_focus(False)
        self.set_resizable(False)
        self.stick()

        outer = Gtk.Box()
        outer.set_margin_start(SHADOW)
        outer.set_margin_end(SHADOW)
        outer.set_margin_top(SHADOW - 6)
        outer.set_margin_bottom(BOTTOM_GAP)
        self.add(outer)
        self.panel = Gtk.Box(spacing=8)
        ui.css_class(self.panel, "lumen-dock")
        outer.pack_start(self.panel, False, False, 0)
        ui.setup_transparency(self, self.panel)

        self.items = {}
        self.trash_count = 0
        self.icon_size = int(shell.settings.get("dock_icon_size", 48))
        self._rebuild_id = 0

        scr = shell.wnck
        for sig in ("window-opened", "window-closed", "application-opened", "application-closed"):
            scr.connect(sig, lambda *_a: self.queue_sync())
        scr.connect("active-window-changed", lambda *_a: self.queue_sync())
        shell.index.connect_changed(self.rebuild)

        self._trash = Gio.File.new_for_uri("trash:///")
        try:
            self._trash_monitor = self._trash.monitor_directory(Gio.FileMonitorFlags.NONE, None)
            self._trash_monitor.connect("changed", lambda *_a: self.update_trash())
        except GLib.Error:
            self._trash_monitor = None

        self.rebuild()
        self.update_trash()

    def animated(self):
        return self.shell.settings.get("animations", "full") != "off"

    # ---------------------------------------------------------- pinned apps
    def pinned(self):
        result = []
        for app_id in self.shell.settings.get("dock_apps", []):
            app = self.shell.index.get(app_id)
            if app is not None and app.get_id() not in result:
                result.append(app.get_id())
        return result

    def set_pinned(self, key, pin):
        current = []
        for a in self.shell.settings.get("dock_apps", []):
            info = self.shell.index.get(a)
            resolved = info.get_id() if info is not None else a
            if not pin and resolved == key:
                continue
            current.append(a)
        if pin and key not in current:
            current.append(key)
        self.shell.settings["dock_apps"] = current
        config.update(dock_apps=current)
        self.rebuild()

    # ---------------------------------------------------------- building
    def reload(self):
        new_size = int(self.shell.settings.get("dock_icon_size", 48))
        self.icon_size = new_size
        self.rebuild()

    def rebuild(self):
        for child in self.panel.get_children():
            self.panel.remove(child)
            child.destroy()
        self.items = {}
        self.launcher_item = DockItem(self, "launcher", kind="launcher")
        self.panel.pack_start(self.launcher_item, False, False, 0)
        self.sep1 = self._sep()
        self.panel.pack_start(self.sep1, False, False, 0)
        self.app_box = Gtk.Box(spacing=8)
        self.panel.pack_start(self.app_box, False, False, 0)
        self.sep2 = self._sep()
        self.panel.pack_start(self.sep2, False, False, 0)
        self.trash_item = DockItem(self, "trash", kind="trash")
        self.panel.pack_start(self.trash_item, False, False, 0)
        self.panel.show_all()
        self.sync()
        self.update_trash()

    def _sep(self):
        s = Gtk.Box()
        s.set_size_request(1, -1)
        ui.css_class(s, "dock-sep")
        return s

    def queue_sync(self):
        if not self._rebuild_id:
            self._rebuild_id = GLib.timeout_add(60, self._do_sync)

    def _do_sync(self):
        self._rebuild_id = 0
        self.sync()
        return False

    def sync(self):
        """Make the app section match: pinned apps first, then other running apps."""
        index = self.shell.index
        running = {}
        sample = {}
        for w in self.shell.wnck.get_windows_stacked() or []:
            if w.is_skip_tasklist() or w.get_window_type() not in (Wnck.WindowType.NORMAL, Wnck.WindowType.DIALOG):
                continue
            key = _key_for_window(index, w)
            running.setdefault(key, []).append(w)
            sample.setdefault(key, w)

        order = list(self.pinned())
        for key in running:
            if key not in order:
                order.append(key)

        for key in list(self.items):
            if key not in order:
                item = self.items.pop(key)
                self.app_box.remove(item)
                item.destroy()
        for pos, key in enumerate(order):
            item = self.items.get(key)
            if item is None:
                app = index.get(key) if not key.startswith("wm:") else None
                item = DockItem(self, key, app=app, wnck_window=sample.get(key))
                self.items[key] = item
                self.app_box.pack_start(item, False, False, 0)
                item.show_all()
            self.app_box.reorder_child(item, pos)
            item.set_running(running.get(key, []))
        self.sep1.set_visible(bool(order))
        self.place()

    # ---------------------------------------------------------- trash
    def update_trash(self):
        def done(f, res):
            try:
                info = f.query_info_finish(res)
                self.trash_count = info.get_attribute_uint32("trash::item-count")
            except GLib.Error:
                self.trash_count = 0
            if getattr(self, "trash_item", None):
                img = self.trash_item.tile.get_children()[0]
                img.set_from_icon_name("user-trash-full-symbolic" if self.trash_count else "user-trash-symbolic",
                                       Gtk.IconSize.DIALOG)
                img.set_pixel_size(max(16, int(self.icon_size * 0.5)))
        self._trash.query_info_async("trash::item-count", Gio.FileQueryInfoFlags.NONE,
                                     GLib.PRIORITY_LOW, None, done)

    def empty_trash(self):
        dlg = Gtk.MessageDialog(message_type=Gtk.MessageType.QUESTION, buttons=Gtk.ButtonsType.NONE,
                                text="Empty the Trash?")
        dlg.format_secondary_text("All %d items in the Trash will be deleted permanently. This can't be undone."
                                  % self.trash_count)
        dlg.add_button("Cancel", Gtk.ResponseType.CANCEL)
        b = dlg.add_button("Empty Trash", Gtk.ResponseType.OK)
        b.get_style_context().add_class("destructive-action")
        dlg.set_keep_above(True)
        if dlg.run() == Gtk.ResponseType.OK:
            ui.run_async(["gio", "trash", "--empty"], lambda *_a: self.update_trash())
        dlg.destroy()

    # ---------------------------------------------------------- placement
    def place(self):
        GLib.idle_add(self._place)

    def _place(self):
        g = ui.primary_geometry()
        self.resize(1, 1)
        _min, nat = self.get_preferred_size()
        w, h = nat.width, nat.height
        self.move(g.x + (g.width - w) // 2, g.y + g.height - h)
        return False
