"""Lumen Shell: top bar, dock, desktop, launcher and power dialog."""
