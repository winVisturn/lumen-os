"""About this computer."""
import os
import platform
import re
import socket

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk  # noqa: E402

from lumen import apps, ui  # noqa: E402
from ..widgets import Page, FormDialog, button, message  # noqa: E402

VM_NAMES = {"oracle": "VirtualBox", "vmware": "VMware", "kvm": "KVM / QEMU", "qemu": "QEMU",
            "microsoft": "Hyper-V", "xen": "Xen", "parallels": "Parallels"}


def _gib(kb):
    return "%.1f GB" % (kb / 1024 / 1024)


def os_name():
    try:
        with open("/etc/os-release") as f:
            data = dict(line.rstrip("\n").split("=", 1) for line in f if "=" in line)
        return data.get("PRETTY_NAME", "Lumen OS 1").strip('"')
    except OSError:
        return "Lumen OS 1"


class AboutPage(Page):
    title = "About"

    def __init__(self, app):
        super().__init__(app)
        hero = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        hero.set_margin_top(6)
        hero.set_margin_bottom(8)
        logo = Gtk.Image.new_from_icon_name("lumen-logo", Gtk.IconSize.DIALOG)
        logo.set_pixel_size(88)
        hero.pack_start(logo, False, False, 0)
        hero.pack_start(ui.label(os_name(), "about-title", xalign=0.5), False, False, 0)
        hero.pack_start(ui.label("A light, calm desktop built on Linux.", "dim-label", xalign=0.5), False, False, 0)
        self.put(hero)

        self.section("This computer")
        self.info = self.card()
        self.name_row = self.info.row("Computer name", socket.gethostname(), button("Rename…", self.rename))
        self.info.row("Processor", self._cpu())
        self.info.row("Memory", self._mem())
        self.gpu_row = self.info.row("Graphics", "Checking…")
        self.info.row("Storage", self._disk())

        self.section("Software")
        sw = self.card()
        sw.row("Kernel", "Linux " + platform.release())
        sw.row("Desktop", "Lumen Shell 1 · X11 · Openbox")
        sw.row("Packages", "Debian 13 base — install more with lpm or apt")
        self.vm_card = None

        tools = Gtk.Box(spacing=8)
        tools.pack_start(button("System info in Terminal", lambda: apps.spawn(
            ["x-terminal-emulator", "-e", "bash -c 'lumenfetch; exec bash'"])), False, False, 0)
        self.put(tools)
        ui.run_async(["glxinfo", "-B"], self._got_gpu)
        ui.run_async(["systemd-detect-virt"], self._got_virt)

    def _cpu(self):
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("model name"):
                        name = line.split(":", 1)[1].strip()
                        name = re.sub(r"\((R|TM)\)", "", name)
                        return "%s · %d threads" % (re.sub(r"\s+", " ", name), os.cpu_count() or 1)
        except OSError:
            pass
        return platform.machine()

    def _mem(self):
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        return _gib(int(line.split()[1]))
        except OSError:
            pass
        return "Unknown"

    def _disk(self):
        try:
            st = os.statvfs("/")
            total = st.f_blocks * st.f_frsize
            free = st.f_bavail * st.f_frsize
            return "%.0f GB free of %.0f GB" % (free / 1e9, total / 1e9)
        except OSError:
            return "Unknown"

    def _got_gpu(self, ok, out, _err):
        m = re.search(r"OpenGL renderer string:\s*(.+)", out or "")
        text = m.group(1).strip() if m else "Unknown"
        if re.search(r"llvmpipe|softpipe", text, re.I):
            text += " (software rendering — Reduced animations recommended)"
        self.gpu_row.subtitle_label.set_text(text)

    def _got_virt(self, ok, out, _err):
        kind = out.strip()
        if not kind or kind == "none":
            return
        name = VM_NAMES.get(kind, kind)
        self.section("Virtual machine")
        card = self.card()
        if kind == "oracle":
            tip = ("Clipboard sharing and auto-resize need VirtualBox Guest Additions: "
                   "Devices > Insert Guest Additions CD, then run “lpm vbox-additions” in Terminal.")
        elif kind == "vmware":
            tip = "VMware Tools (open-vm-tools) are already installed."
        else:
            tip = "SPICE and QEMU guest tools are already installed."
        card.row("Running in %s" % name, tip)
        card.show_all()

    def rename(self):
        dlg = FormDialog(self.window, "Rename this computer", "Rename")
        entry = dlg.field("Name", Gtk.Entry())
        entry.set_text(socket.gethostname())
        dlg.note("Other devices on your network see this name. Use letters, numbers and dashes.")
        entry.connect("changed", lambda e: dlg.ok.set_sensitive(bool(re.match(
            r"^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?$", e.get_text()))))
        dlg.show_all()
        res = dlg.run()
        name = entry.get_text()
        dlg.destroy()
        if res != Gtk.ResponseType.OK or name == socket.gethostname():
            return

        def done(ok, _o, err):
            if ok:
                self.name_row.subtitle_label.set_text(name)
            else:
                message(self.window, "Couldn't rename the computer", (err or "").strip(), Gtk.MessageType.ERROR)
        ui.run_async(["pkexec", "/usr/libexec/lumen/lumen-users-admin", "set-hostname", name], done)
