/* Lumen OS installer slideshow */
import QtQuick 2.0;
import calamares.slideshow 1.0;

Presentation
{
    id: presentation

    function nextSlide() {
        presentation.goToNextSlide();
    }

    Timer {
        id: advanceTimer
        interval: 7000
        running: presentation.activatedInCalamares
        repeat: true
        onTriggered: nextSlide()
    }

    Slide {
        Rectangle { anchors.fill: parent; color: "#EEF1F4" }
        Image {
            id: logo1
            source: "logo.png"
            width: 96; height: 96
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top; anchors.topMargin: 60
        }
        Text {
            anchors.top: logo1.bottom; anchors.topMargin: 24
            anchors.horizontalCenter: parent.horizontalCenter
            width: parent.width * 0.75
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            color: "#1F2A33"; font.pixelSize: 22; font.family: "Inter"
            text: "Welcome to Lumen OS"
        }
        Text {
            anchors.bottom: parent.bottom; anchors.bottomMargin: 70
            anchors.horizontalCenter: parent.horizontalCenter
            width: parent.width * 0.7
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            color: "#5B6873"; font.pixelSize: 15; font.family: "Inter"
            text: "A light, calm desktop that runs well on older computers."
        }
    }

    Slide {
        Rectangle { anchors.fill: parent; color: "#EEF1F4" }
        Text {
            anchors.centerIn: parent
            width: parent.width * 0.7
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            color: "#1F2A33"; font.pixelSize: 18; font.family: "Inter"
            text: "Make it yours: Light, Soft dim or Dusk mode, five accent colours and your own wallpaper — in Settings › Personalise."
        }
    }

    Slide {
        Rectangle { anchors.fill: parent; color: "#EEF1F4" }
        Text {
            anchors.centerIn: parent
            width: parent.width * 0.7
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            color: "#1F2A33"; font.pixelSize: 18; font.family: "Inter"
            text: "Share the computer: add accounts for everyone, or turn on the Guest account — in Settings › Users."
        }
    }

    Slide {
        Rectangle { anchors.fill: parent; color: "#EEF1F4" }
        Text {
            anchors.centerIn: parent
            width: parent.width * 0.7
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            color: "#1F2A33"; font.pixelSize: 18; font.family: "Inter"
            text: "Get more apps from the terminal with lpm install, and keep up to date in Settings › Updates."
        }
    }

    function onActivate() { presentation.currentSlide = 0; }
    function onLeave() { }
}
