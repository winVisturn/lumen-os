#!/bin/bash
# Build the Lumen OS 1 installer ISO.
#
#   sudo ./build.sh           build (reuses downloaded packages from last time)
#   sudo ./build.sh --clean   start completely fresh
#
# Run this on Debian 13 ("trixie"), e.g. in a VirtualBox VM. Needs internet,
# about 15 GB of free disk space, and 20-60 minutes.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

if [ "$(id -u)" -ne 0 ]; then
    exec sudo -- "$0" "$@"
fi

say() { printf '\n\033[1;36m==>\033[0m \033[1m%s\033[0m\n' "$*"; }
warn() { printf '\033[1;33mWarning:\033[0m %s\n' "$*"; }

. /etc/os-release
if [ "${ID:-}" != "debian" ] || [ "${VERSION_CODENAME:-}" != "trixie" ]; then
    warn "This should be built on Debian 13 (trixie). You're on ${PRETTY_NAME:-something else}."
    warn "It may still work, but if the build fails, use a Debian 13 VM."
    sleep 3
fi

if ! command -v lb >/dev/null; then
    say "Installing live-build"
    apt-get update
    apt-get install -y live-build
fi

say "Checking project files"
chmod +x auto/* config/hooks/normal/*.hook.chroot
chmod +x config/includes.chroot/usr/bin/* config/includes.chroot/usr/libexec/lumen/*
find config/includes.chroot -name '__pycache__' -prune -exec rm -rf {} +

say "Choosing optional packages"
: > config/package-lists/optional.list.chroot
skipped=()
while read -r pkg; do
    case "$pkg" in ''|'#'*) continue ;; esac
    if apt-cache show "$pkg" >/dev/null 2>&1; then
        echo "$pkg" >> config/package-lists/optional.list.chroot
    else
        skipped+=("$pkg")
    fi
done < config/optional-packages.txt
echo "Including $(wc -l < config/package-lists/optional.list.chroot) optional packages."
if [ ${#skipped[@]} -gt 0 ]; then
    warn "Not found on this machine, so left out: ${skipped[*]}"
    warn "(Firmware packages need 'non-free-firmware' in /etc/apt/sources.list on the build machine.)"
fi

if [ "${1:-}" = "--clean" ]; then
    say "Cleaning everything (packages will be downloaded again)"
    lb clean --purge || true
else
    lb clean || true
fi

say "Configuring"
lb config

say "Building Lumen OS 1 — this takes a while (full log: build.log)"
start=$(date +%s)
if ! lb build; then
    echo
    warn "The build failed. The end of build.log usually says why."
    warn "Send me the last 40 lines:  tail -n 40 build.log"
    exit 1
fi

iso=$(ls -t ./*.iso 2>/dev/null | head -n1 || true)
if [ -z "$iso" ]; then
    warn "Build finished but no ISO was found. Check build.log."
    exit 1
fi
final="lumen-os-1-amd64.iso"
[ "$iso" = "./$final" ] || mv -f "$iso" "$final"
sha256sum "$final" > "$final.sha256"
mins=$(( ($(date +%s) - start) / 60 ))
say "Done in ${mins} min: $(pwd)/$final ($(du -h "$final" | cut -f1))"
echo "Boot it in a new VM, or write it to a USB stick (e.g. with balenaEtcher or Rufus in DD mode)."
